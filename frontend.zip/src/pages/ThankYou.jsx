// src/pages/ThankYou.jsx
import React from "react";
import { useLocation, Navigate, Link } from "react-router-dom";
import Container from "./../components/ui/Container";
import Header from "../components/Header";

const ThankYou = () => {
  const location = useLocation();
  const order = location?.state?.order;

  // Protect the route: redirect if no order data
  if (!order) {
    return <Navigate to="/" replace />;
  }

  return (
    // <div className="thank-you-page">
    //   <h1>Thank You for Your Order!</h1>
    //   <p>
    //     Your order ID is: <strong>{order.id}</strong>
    //   </p>
    //   <p>
    //     Transaction ID: <strong>{order.transactionId}</strong>
    //   </p>
    // </div>
    <div className="w-full">
      <Header />
      <section className="py-5">
        <Container>
          <div className="orderConfirmation">
            <h1 className="text-primary font-bold font-primary text-4xl mb-10 mt-5">
              Thank you!
            </h1>
            <p className="text-sm text-primary font-normal font-primary mb-5">
              <span>
                Your order number is <strong>{order.id}</strong>
              </span>
            </p>
            <p className="text-sm text-primary font-normal font-primary">
              <span>
                An email will be sent containing information about your
                purchase. If you have any questions about your purchase, email
                us at{" "}
                <Link
                  className="block text-sky-600 font-medium"
                  target="_top"
                  to="mailto:subrata.haldar@codeclouds.com?Subject=Order 451"
                >
                  subrata.haldar@codeclouds.com
                </Link>
                .
              </span>
            </p>
            <div className="continueButtonContainer mt-5">
              <Link
                className="text-primary uppercase font-primary font-medium text-md border border-[#ccc] px-5 py-3 hover:bg-primary hover:text-white"
                to="/"
              >
                Continue Shopping »
              </Link>
            </div>
          </div>
        </Container>
      </section>
    </div>
  );
};

export default ThankYou;
