import { setPaymentError } from "../redux/errorSlice";

export const processPaymentThunk = (paymentInstrument, accessToken) => {
  return async (dispatch) => {
    try {
      const res = await fetch("/api/process-payment", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${accessToken}`,
        },
        body: JSON.stringify({ paymentInstrument }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data?.message || "Payment failed.");
      }

      return data;
    } catch (error) {
      dispatch(setPaymentError(error.message));
      throw error;
    }
  };
};
