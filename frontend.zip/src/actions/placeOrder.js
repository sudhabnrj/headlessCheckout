import { setPaymentError } from "../redux/errorSlice";

export const placeOrderThunk = (
  checkoutID,
  selectedPaymentMethod,
  paymentInstrument
) => {
  return async (dispatch) => {
    try {
      const response = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          checkoutID,
          selectedPaymentMethod,
          paymentInstrument,
        }),
      });

      const data = await response.json();

      if (!response.ok || !data?.data?.id) {
        throw new Error("Failed to place order or missing order ID.");
      }

      return data;
    } catch (error) {
      dispatch(setPaymentError(error.message));
      throw error;
    }
  };
};
