/* eslint-disable react-hooks/exhaustive-deps */
import "../src/styles/App.css";
import Header from "./components/Header";
import Container from "./components/ui/Container";
import CartSidebar from "./components/CartSidebar";
import useCheckout from "./hooks/useCheckout";
import { useLocation } from "react-router-dom";
import ShippingMethodForm from "./components/ShippingMethodForm";
import AlertError from "./components/ui/AlertError";
import { useEffect, useState } from "react";
import useCustomerAddresses from "./hooks/useCustomerAddresses";
import { useDispatch, useSelector } from "react-redux";
import Title from "./components/ui/Title";
import Button from "./components/ui/Button";
import ShippingAddressForm from "./components/ShippingAddressForm";
import ShippingOptions from "./components/ShippingOptions";
import RadioButton from "./components/ui/RadioButton";
import { API_URL } from "./lib/constant";
import { addCheckoutData } from "./redux/checkoutSlice";
import BillingAddressForm from "./components/BillingAddressForm";
import { createBillingAddress } from "./lib/createBillingAddress";
// import PaymentTab from "./components/PaymentTab";
import VisaIcon from "./components/ui/VisaIcon";
import MasterCardIcon from "./components/ui/MasterCardIcon";
import DiscoverIcon from "./components/ui/DiscoverIcon";
import AmericanExpressIcon from "./components/ui/AmericanExpressIcon";
import { TiLockClosed } from "react-icons/ti";
import Input from "./components/ui/Input";
import Label from "./components/ui/Label";
import GetPaymentMethod from "./lib/GetPaymentMethod";
import { FetchGeoLocation } from "./lib/FetchGeoLocation";
import useDebouncedGeoFetch from "./hooks/useDebouncedGeoFetch";
import { fetchPickupOptions } from "./lib/fetchPickupOptions";
import { handleShippingAndPickup } from "./lib/handleShippingAndPickup";
import { editEmail, setEmail } from "./redux/emailSlice";
import { Validate } from "./lib/Validate";
import { placeOrder } from "./lib/placeOrder";
import EmailForm from "./components/EmailForm";
import ShippingAddress from "./components/ShippingAddress";
import { setPaymentMethods } from "./redux/paymentSlice";
import { useNavigate } from "react-router-dom";
import BillingAddress from "./components/BillingAddress";
import { updateBillingAddressAPI } from "./lib/updateBillingAddress";

const useQuery = () => new URLSearchParams(useLocation().search);

function App() {
  const query = useQuery();
  const checkoutID = query.get("cartId");

  if (!checkoutID) {
    console.error("Cart ID is missing from the URL!");
  }

  const updatedCheckoutResult =
    useSelector((store) => store.checkout.checkoutData) || {};
  const checkoutResult =
    useSelector((store) => store.checkout.checkoutData) || {};
  const customerDetails = useSelector((state) => state.customer.customer) || [];
  const isLoading = useSelector((state) => state.loader.loading);
  const error = useSelector((state) => state.error.error);
  const email = useSelector((state) => state.email.email);
  const updatedBilling_address =
    useSelector((state) => state.checkout.checkoutData) || {};
  const paymentMethods = useSelector((state) => state.payment.paymentMethods);

  const [response, setResponse] = useState(null);
  const [pickupOption, setPickupOption] = useState("");
  const [loading, setLoading] = useState(false);
  const [isError, setIsError] = useState(null);
  const [selectedRadioButton, setSelectedRadioButton] = useState(null);
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState(
    "bigcommerce_manual_payment"
  );
  // const [paymentMethods, setPaymentMethods] = useState(null);
  const [geoLocation, setGeoLocation] = useState(null);
  const [openDropdown, setOpenDropdown] = useState(false);
  // const [step, setStep] = useState(1);
  const [custEmail, setCustEmail] = useState("");
  const [isEmailSubmitted, setIsEmailSubmitted] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isBillingEditing, setIsBillingEditing] = useState(false);

  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    companyName: "",
    phoneNumber: "",
    address: "",
    apartment: "",
    city: "",
    country: "",
    state: "",
    postalCode: "",
  });
  const [billingFormData, setBillingFormData] = useState({
    firstName: "",
    lastName: "",
    companyName: "",
    phoneNumber: "",
    address: "",
    apartment: "",
    city: "",
    country: "",
    state: "",
    postalCode: "",
  });

  const dispatch = useDispatch();
  const customerID = checkoutResult?.data?.cart?.customer_id || null;
  useCustomerAddresses(customerID);
  const defaultShippingAddress =
    updatedCheckoutResult?.data?.cart?.consignments?.[0]?.shipping_address ||
    null;
  const cartItems =
    checkoutResult?.data?.cart?.line_items?.physical_items || [];

  useEffect(() => {
    if (
      customerDetails.length > 0 &&
      (!selectedAddress || !selectedAddress.id)
    ) {
      setSelectedAddress(customerDetails[0]);
    }
  }, [customerDetails]);

  const [selectedAddress, setSelectedAddress] = useState(
    defaultShippingAddress
  );

  //Fetch geolocation
  useDebouncedGeoFetch(formData, 500);

  // Fetch shipping methods when geoLocation is available
  useEffect(() => {
    if (geoLocation) {
      submitShippingMethod();
    }
  }, [geoLocation]);

  const handleDropdownOpen = () => {
    console.log("Dropdown clicked");
    setOpenDropdown((prev) => !prev);
  };

  const handleAddressSelect = (address) => {
    setSelectedAddress(address);
    setOpenDropdown(false);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleChangeBillingForm = (e) => {
    const { name, value } = e.target;
    setBillingFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleEmailChange = (e) => {
    setCustEmail(e.target.value);
  };

  const handleEmailSubmit = () => {
    const errors = Validate({ email: custEmail }, true); // Pass email for validation

    if (errors.email) {
      alert(errors.email); // Show validation error
      return;
    }
    dispatch(setEmail(custEmail));
    setIsEmailSubmitted(true);
  };

  const handleEditEmail = () => {
    dispatch(editEmail()); // ✅ Clear email in Redux
    setCustEmail(""); // Reset local state
    setIsEmailSubmitted(false); // Show form again
  };

  // const { email } = checkoutResult?.data?.cart || {};

  const { available_shipping_options } = response?.data?.consignments[0] || {};

  //Select first time shipping method
  useEffect(() => {
    if (available_shipping_options?.length > 0 && !selectedRadioButton) {
      setSelectedRadioButton(available_shipping_options[0].id);
    }
  }, [available_shipping_options]); // Runs when shipping options update

  //Submit Shipping Address
  const submitShippingMethod = async (e) => {
    e.preventDefault();
    setLoading(true);
    setIsError(null);

    const {
      firstName,
      lastName,
      address,
      city,
      country,
      state,
      postalCode,
      phoneNumber,
      companyName,
      apartment,
    } = formData;

    if (
      !firstName ||
      !lastName ||
      !address ||
      !city ||
      !country ||
      !postalCode
    ) {
      setIsError("Please fill in all required fields.");
      setLoading(false);
      return;
    }

    try {
      //Fetch Geolocation
      const geoLocation = await FetchGeoLocation(
        address,
        city,
        state,
        postalCode,
        country
      );

      console.log("shipping geoLocation", geoLocation);

      // Construct payload dynamically
      const payload = [
        {
          address: {
            email,
            country_code: country,
            first_name: firstName,
            last_name: lastName,
            address1: address,
            city: city,
            state_or_province: state,
            state_or_province_code: state,
            postal_code: postalCode,
            phone: phoneNumber,
            custom_fields: [
              {
                field_id: "field_25",
                field_value: "Great!",
              },
            ],
          },
          line_items: cartItems.map((item) => ({
            item_id: item.id,
            quantity: item.quantity,
          })),
          coordinates: geoLocation,
        },
        {
          address: {
            email,
            country_code: country,
            first_name: firstName,
            last_name: lastName,
            company: companyName,
            address1: address,
            address2: apartment,
            city: city,
            state_or_province: state,
            state_or_province_code: state,
            postal_code: postalCode,
            phone: phoneNumber,
            custom_fields: [
              {
                field_id: "field_25",
                field_value: "You're Welcome",
              },
            ],
          },
          line_items: cartItems.map((item) => ({
            item_id: item.id,
            quantity: item.quantity,
          })),
          coordinates: geoLocation,
        },
      ];

      const res = await fetch(
        `${API_URL}/checkouts/${checkoutID}/consignments?include=consignments.available_shipping_options`,
        {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            "X-Auth-Token": import.meta.env.VITE_APP_ACCESS_TOKEN,
          },
          body: JSON.stringify(payload),
          cache: "no-cache",
        }
      );

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.title || "Failed to submit shipping method");
      }

      const data = await res.json();
      // console.log("API Response:", data);
      setResponse(data);
      await fetchPickupOptions(
        geoLocation,
        cartItems,
        setPickupOption,
        setLoading,
        setIsError
      );

      console.log("Shipping Form Response:", data?.data);
    } catch (error) {
      console.error("Submission Error:", error);
      setIsError(error.message);
    } finally {
      setLoading(false);
    }
  };

  //Submit Shipping method or Pickup Method
  const handleSelection = async () => {
    setLoading(true); // Start loading
    setIsError(null); // Reset error state
    try {
      await handleShippingAndPickup(
        selectedRadioButton,
        available_shipping_options,
        checkoutID,
        submitShippingMethod,
        event,
        dispatch,
        addCheckoutData,
        checkoutResult
      );

      setIsSubmitted(true); // Hide button after successful submission
    } catch (error) {
      console.error("Error submitting method:", error);
      setIsError(error.message);
    } finally {
      setLoading(false); // Stop loading after response
    }
  };

  const { shipping_address, selected_shipping_option, selected_pickup_option } =
    checkoutResult?.data?.consignments[0] || {};

  const billingAddress =
    updatedBilling_address?.data?.billing_address?.data?.billing_address || // Case 1: After form submission
    updatedBilling_address?.data?.billing_address; // Case 2: After reloading

  const addressID = billingAddress?.id || null;

  //Populate Billing form after Clicking Edit
  useEffect(() => {
    if (billingAddress) {
      setBillingFormData({
        firstName: billingAddress.first_name,
        lastName: billingAddress.last_name,
        companyName: billingAddress.company,
        phoneNumber: billingAddress.phone,
        address: billingAddress.address1,
        apartment: billingAddress.address2,
        city: billingAddress.city,
        country: billingAddress.country_code,
        state: billingAddress.state_or_province,
        postalCode: billingAddress.postal_code,
      });
    }
  }, [billingAddress]);

  //Create Billing Form
  const handleBillingForm = async (e) => {
    e.preventDefault();
    setLoading(true);
    setIsError(null);

    // Ensure all required fields are present
    const { address, city, country, state, postalCode } = billingFormData;

    if (!address || !city || !country || !state || !postalCode) {
      setIsError("Please fill in all required fields.");
      setLoading(false);
      return;
    }

    try {
      let updatedBillingData;
      if (billingAddress && Object.keys(billingAddress).length > 0) {
        updatedBillingData = await updateBillingAddressAPI(
          checkoutID,
          addressID,
          email,
          billingFormData
        );
      } else {
        updatedBillingData = await dispatch(
          createBillingAddress(
            billingFormData,
            checkoutID,
            email,
            checkoutResult
          )
        );
      }

      // Update Redux store
      dispatch(
        addCheckoutData({
          ...checkoutResult,
          data: {
            ...checkoutResult.data,
            billing_address: updatedBillingData,
          },
        })
      );

      console.log("Billing address updated successfully.");
      setIsBillingEditing(false); // Hide the form after successful update

      // setStep(3);
      const getPaymentMethods = await GetPaymentMethod();

      if (Array.isArray(getPaymentMethods) && getPaymentMethods.length > 0) {
        // setPaymentMethods(getPaymentMethods);
        dispatch(setPaymentMethods(getPaymentMethods));
      } else {
        setIsError("No payment methods available.");
      }

      // Navigate to the next step or update UI state
    } catch (error) {
      console.error(error.message || "Something went wrong. Please try again.");
    } finally {
      setLoading(false); // Ensure loading state is reset
    }
  };

  // Handle Payment Method Selection
  const handlePaymentDropdown = (e) => {
    setSelectedPaymentMethod(e.target.id);
  };

  // Place Order  - Handle Payment
  const handlePlaceOrder = async (e) => {
    e.preventDefault();
    try {
      if (!checkoutID) {
        console.error("Checkout ID is missing!");
        return;
      }

      const orderData = await placeOrder(checkoutID, selectedPaymentMethod);
      console.log("Order Confirmed:", orderData);

      // Show success message
      alert("Payment successful! Redirecting...");

      // Redirect after 3 seconds
      setTimeout(() => {
        window.location.href = "https://headlessreact.mybigcommerce.com/";
      }, 3000);
    } catch (error) {
      console.error("Failed to place order:", error);
      alert("Order placement failed. Please try again.");
    }
  };

  if (error) {
    return <AlertError message={error} />;
  }

  return (
    <>
      <Header />
      <section className="py-4">
        <Container>
          <div className="flex justify-between items-start">
            <form className="w-[70%] max-w-[603px] flex flex-col gap-8">
              <div className="w-full border-b border-gray-200 pb-5">
                <Title title="Customer" />
                {isEmailSubmitted ? (
                  <div className="flex w-full items-center justify-between py-5">
                    <div className="flex justify-start items-center">
                      <span className="font-primary text-primary font-medium text-sm">
                        {email}
                      </span>
                    </div>
                    <Button
                      onClick={handleEditEmail}
                      className={
                        "!text-primary bg-transparent border border-primary "
                      }
                    >
                      Edit
                    </Button>
                  </div>
                ) : (
                  <div className="mt-8">
                    <EmailForm
                      custEmail={custEmail}
                      handleEmailChange={handleEmailChange}
                      handleEmailSubmit={handleEmailSubmit}
                    />
                  </div>
                )}
              </div>
              <div className="w-full border-b border-gray-200">
                <>
                  <Title title="Shipping" />
                  <div className="mt-8">
                    <div className="w-full flex flex-col gap-4">
                      {shipping_address &&
                      Object.keys(shipping_address).length > 0 ? (
                        <>
                          <div className="flex justify-between items-center">
                            <ShippingAddress data={shipping_address} />
                            <Button
                              type="button"
                              // onClick={handleUpdateConsignment}
                              className={
                                "!text-primary bg-transparent border border-primary "
                              }
                            >
                              Edit
                            </Button>
                          </div>
                        </>
                      ) : (
                        <>
                          <div className="shipping-header mt-5 mb-3">
                            <h3 className="font-semibold font-primary text-primary text-base mb-5">
                              Shipping Address
                            </h3>
                          </div>
                          <ShippingAddressForm
                            formData={formData}
                            handleChange={handleChange}
                          />
                        </>
                      )}

                      {selected_shipping_option ? (
                        <>
                          <h3 className="font-bold font-primary text-primary text-base mb-0 mt-5">
                            Shipping Method
                          </h3>
                          <div>
                            <hr className="my-2 border-gray-300" />
                            <p className="text-sm text-gray-700">
                              {selected_shipping_option?.description}{" "}
                              <span className="font-bold">{`₹${selected_shipping_option?.cost.toFixed(
                                2
                              )}`}</span>
                            </p>
                          </div>
                        </>
                      ) : selected_pickup_option ? (
                        <p className="text-sm bg-green-300 text-green-800 p-3 font-bold rounded-md">
                          You have selected Pickup method
                        </p>
                      ) : available_shipping_options?.length > 0 ? (
                        <>
                          <h3 className="font-bold font-primary text-primary text-base mb-0 mt-5">
                            Shipping Method
                          </h3>
                          {available_shipping_options?.map((shipping) => (
                            <ShippingOptions
                              key={shipping?.id}
                              id={shipping?.id}
                              label={shipping?.description}
                              checked={selectedRadioButton === shipping.id}
                              onChange={() =>
                                setSelectedRadioButton(shipping.id)
                              }
                              shippingCost={`₹${shipping?.cost.toFixed(2)}`}
                            />
                          ))}
                        </>
                      ) : (
                        <div className="checkout-shipping-options border border-gray-300 p-10 w-full bg-[#f5f5f5]">
                          Please enter a shipping address to see shipping
                          quotes.
                        </div>
                      )}

                      {/* Pickup Section - Only show if no shipping method is selected */}
                      {!selected_shipping_option &&
                      !selected_pickup_option &&
                      pickupOption?.pickup_options?.length > 0 ? (
                        <>
                          <h3 className="font-bold font-primary text-primary text-base mb-0 mt-5">
                            Pickup Location
                          </h3>
                          {pickupOption?.pickup_options.map(
                            (picLocation, index) => (
                              <div
                                key={index}
                                className="checkout-shipping-options border border-gray-300 p-5 w-full bg-[#f5f5f5]"
                              >
                                <div className="flex justify-between items-center">
                                  <div className="flex justify-start items-center flex-col gap-4">
                                    <RadioButton
                                      name="customMethod"
                                      id={picLocation?.pickup_method?.id}
                                      label={
                                        picLocation?.pickup_method?.display_name
                                      }
                                      description={
                                        picLocation?.pickup_method
                                          ?.collection_instructions
                                      }
                                      checked={
                                        selectedRadioButton ===
                                        picLocation?.pickup_method?.id
                                      }
                                      onChange={() => {
                                        setSelectedRadioButton(
                                          picLocation?.pickup_method?.id
                                        );
                                        setSelectedPickupOption(
                                          picLocation?.pickup_method
                                        ); // Store selection in state or Redux
                                      }}
                                    />
                                  </div>
                                  <div className="shippingCost justify-end items-center">
                                    <span className="shippingOption-price text-primary font-bold font-primary">
                                      {
                                        picLocation?.pickup_method
                                          ?.collection_time_description
                                      }
                                    </span>
                                  </div>
                                </div>
                              </div>
                            )
                          )}
                        </>
                      ) : null}

                      <div className="w-full">
                        {!response ? (
                          !selected_shipping_option &&
                          !checkoutResult?.data?.consignments.length ? (
                            <Button
                              onClick={submitShippingMethod}
                              type="button"
                              className="min-w-[231px] py-3 px-4"
                              disabled={loading}
                            >
                              {loading ? "Loading..." : "Continue"}
                            </Button>
                          ) : null
                        ) : !isSubmitted ? (
                          <Button
                            onClick={handleSelection}
                            type="button"
                            className="min-w-[231px] py-3 px-4"
                            disabled={loading}
                          >
                            {loading ? "Loading..." : "Next"}
                          </Button>
                        ) : null}
                      </div>
                    </div>
                    {isError && <p className="text-red-500">{isError}</p>}
                    {/* {response && (
                      <p className="text-green-500">
                        Shipping method submitted successfully!
                      </p>
                    )} */}
                  </div>
                </>

                <div className="py-4 border-b border-gray-200">
                  <Title
                    className="mt-10 pt-10 border-t border-gray-300"
                    title="Billing"
                  />
                  {isBillingEditing ? (
                    <div className="mt-10">
                      <div className="w-full flex flex-col gap-4">
                        <BillingAddressForm
                          billingFormData={billingFormData}
                          handleChange={handleChangeBillingForm}
                        />
                        <div className="w-full mt-5 mb-8">
                          <Button
                            onClick={handleBillingForm}
                            type="button"
                            className="min-w-[231px] py-3 px-4"
                            disabled={loading}
                          >
                            {loading ? "Processing..." : "Continue"}
                          </Button>
                        </div>
                      </div>
                    </div>
                  ) : billingAddress &&
                    Object.keys(billingAddress).length > 0 ? (
                    <>
                      <div className="flex justify-between items-center">
                        <BillingAddress data={billingAddress} />
                        <Button
                          type="button"
                          onClick={() => setIsBillingEditing(true)}
                          className={
                            "!text-primary bg-transparent border border-primary "
                          }
                        >
                          Edit
                        </Button>
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="shipping-header mt-5 mb-3">
                        <h3 className="font-semibold font-primary text-primary text-base mb-5">
                          Billing Address
                        </h3>
                      </div>

                      <div className="mt-10">
                        <div className="w-full flex flex-col gap-4">
                          <BillingAddressForm
                            billingFormData={billingFormData}
                            handleChange={handleChangeBillingForm}
                          />
                          <div className="w-full mt-5 mb-8">
                            <Button
                              onClick={handleBillingForm}
                              type="button"
                              className="min-w-[231px] py-3 px-4"
                              disabled={loading}
                            >
                              {loading ? "Processing..." : "Continue"}
                            </Button>
                          </div>
                        </div>
                      </div>
                    </>
                  )}
                </div>

                <div className="p-4 rounded-lg mt-4">
                  {billingAddress && paymentMethods.length > 0 && (
                    <>
                      <Title title={"Payment"} />
                      <div className="w-full border-b border-gray-200">
                        <div className="mt-8">
                          <div className="accordian border border-gray-300 w-full">
                            {paymentMethods?.map((payment) => (
                              <div
                                key={payment.code}
                                className="accordian-tab bg-gray-100"
                              >
                                {/* Payment Method Selection */}
                                <div className="accordian-header w-full flex justify-between items-center px-4 py-3 border-b border-gray-300 min-h-[81px]">
                                  <RadioButton
                                    name="paymentCard"
                                    id={`checkout_${payment.code}`}
                                    label={payment?.name}
                                    checked={
                                      selectedPaymentMethod ===
                                      `checkout_${payment.code}`
                                    }
                                    onChange={handlePaymentDropdown}
                                  />

                                  {/* Show Card Icons for Manual Payment */}
                                  {payment.code ===
                                    "checkout_bigcommerce_manual_payment" && (
                                    <div className="flex justify-end items-center">
                                      <VisaIcon />
                                      <MasterCardIcon />
                                      <DiscoverIcon />
                                      <AmericanExpressIcon />
                                    </div>
                                  )}
                                </div>

                                {/* Show Card Fields Only for Manual Payment */}
                                {selectedPaymentMethod === payment.code &&
                                  payment.code ===
                                    "checkout_bigcommerce_manual_payment" && (
                                    <div className="accordian-body border-b border-gray-300 p-4">
                                      <div className="w-full flex justify-between items-center gap-4">
                                        <div className="flex flex-col w-[80%]">
                                          <Label label={"Credit Card Number"} />
                                          <div className="relative">
                                            <Input
                                              className="pr-12 bg-white"
                                              type="text"
                                              name="creditCardNumber"
                                            />
                                            <span className="absolute top-1 right-2">
                                              <TiLockClosed className="w-8 h-8 fill-gray-500" />
                                            </span>
                                          </div>
                                        </div>
                                        <div className="flex flex-col w-[20%]">
                                          <Label label={"Expiration"} />
                                          <Input
                                            className="bg-white"
                                            type="text"
                                            name="expiration"
                                            placeholder={"MM/YY"}
                                          />
                                        </div>
                                      </div>

                                      <div className="w-full flex justify-between items-center gap-4 mt-5">
                                        <div className="flex flex-col w-[80%]">
                                          <Label label={"Name on Card"} />
                                          <Input
                                            className="bg-white"
                                            type="text"
                                            name="cardHolderName"
                                          />
                                        </div>
                                        <div className="flex flex-col w-[20%]">
                                          <Label label={"CVV"} />
                                          <div className="relative">
                                            <Input
                                              className="bg-white"
                                              type="text"
                                              name="cvv"
                                            />
                                            <span className="absolute top-1 right-2">
                                              <TiLockClosed className="w-8 h-8 fill-gray-500" />
                                            </span>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  )}
                              </div>
                            ))}
                          </div>

                          {/* Place Order Button */}
                          <Button
                            type="button"
                            onClick={handlePlaceOrder}
                            className="w-full py-3 px-4 uppercase text-xl mt-5"
                          >
                            Place Order
                          </Button>
                        </div>
                      </div>
                    </>
                  )}
                </div>
              </div>
            </form>

            <div className="cart-sidebar w-[30%] max-w-[357px]">
              <CartSidebar checkoutID={checkoutID} />
            </div>
          </div>
        </Container>
      </section>
    </>
  );
}

export default App;
