import { configureStore } from "@reduxjs/toolkit";
import checkoutReducer from "../redux/checkoutSlice";
import loaderReducer from "../redux/loaderSlice";
import errorReducer from "../redux/errorSlice";
import customerReducer from "../redux/customerSlice";
import cartReducer from "../redux/cartSlice";
import emailReducer from "../redux/emailSlice";
import shippingOptionsReducer from "../redux/shippingSlice";
import paymentReducer from "../redux/paymentSlice";
import storeLocationReducer from "../redux/inventoryLocationSlice";

const store = configureStore({
  reducer: {
    email: emailReducer,
    checkout: checkoutReducer,
    cart: cartReducer,
    shippingOptions: shippingOptionsReducer,
    customer: customerReducer,
    storeLocation: storeLocationReducer,
    loader: loaderReducer,
    error: errorReducer,
    payment: paymentReducer,
  },
});

export default store;
