import { createSlice } from "@reduxjs/toolkit";

const cartSlice = createSlice({
  name: "cart",
  initialState: {
    cartData: [],
    coupon: null,
  },
  reducers: {
    addCartData: (state, action) => {
      state.cartData = action.payload;
    },
    clearCart: (state) => {
      state.cartData = [];
    },
    applyCoupon: (state, action) => {
      state.coupon = action.payload; // Store applied coupon
    },
    clearCoupon: (state) => {
      state.coupon = null;
    },
  },
});

export const { addCartData, clearCart, applyCoupon, clearCoupon } =
  cartSlice.actions;
export default cartSlice.reducer;
