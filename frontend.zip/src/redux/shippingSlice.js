import { createSlice } from "@reduxjs/toolkit";

const shippingSlice = createSlice({
  name: "shippingOptions",
  initialState: {
    shippingMethod: null,
    pickupDetails: null,
  },
  reducers: {
    setShippingMethod: (state, action) => {
      state.shippingMethod = action.payload;
      state.pickupMethod = null;
    },
    setPickupMethod: (state, action) => {
      state.pickupMethod = action.payload;
      state.shippingMethod = null;
    },
  },
});

export const { setShippingMethod, setPickupMethod } = shippingSlice.actions;
export default shippingSlice.reducer;
