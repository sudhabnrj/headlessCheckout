import { createSlice } from "@reduxjs/toolkit";

const checkoutSlice = createSlice({
  name: "checkout",
  initialState: {
    checkoutData: null,
    availableShippingOptions: [],
    availablePickupOptions: [],
    checkoutError: null,
    selectedShippingOption: null,
    selectedPickupOption: null,
    selectedRadioButton: null,
  },
  reducers: {
    addCheckoutData: (state, action) => {
      state.checkoutData = { ...state.checkoutData, ...action.payload };
    },
    setAvailableShippingOptions: (state, action) => {
      state.availableShippingOptions = action.payload;
    },
    setAvailablePickupOptions: (state, action) => {
      state.availablePickupOptions = action.payload; // ✅ Store pickup options
    },
    setCheckoutError: (state, action) => {
      state.checkoutError = action.payload;
    },

    setSelectedShippingOption: (state, action) => {
      state.selectedShippingOption = action.payload;
      state.selectedPickupOption = null; // ✅ Clear pickup if shipping is selected
      state.selectedRadioButton = action.payload?.id || null;
    },

    setSelectedPickupOption: (state, action) => {
      state.selectedPickupOption = action.payload;
      state.selectedShippingOption = null; // ✅ Clear shipping if pickup is selected
      state.selectedRadioButton = action.payload?.id || null;
    },

    setSelectedRadioButton: (state, action) => {
      state.selectedRadioButton = action.payload;
    },
    resetCheckout: (state) => {
      state.checkoutData = null;
      state.availableShippingOptions = [];
      state.availablePickupOptions = [];
      state.checkoutError = null;
      state.selectedShippingOption = null;
      state.selectedPickupOption = null;
      state.selectedRadioButton = null;
    },
  },
});

export const {
  addCheckoutData,
  setAvailableShippingOptions,
  setAvailablePickupOptions,
  setSelectedShippingOption,
  setSelectedPickupOption,
  setSelectedRadioButton,
  setCheckoutError,
  resetCheckout,
} = checkoutSlice.actions;
export default checkoutSlice.reducer;
