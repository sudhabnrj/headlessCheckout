import { createSlice } from "@reduxjs/toolkit";

const inventoryLocationSlice = createSlice({
  name: "storeLocation",
  initialState: {
    storeLocationData: null,
  },
  reducers: {
    addStoreLocation: (state, action) => {
      state.storeLocationData = action.payload;
    },
  },
});

export const { addStoreLocation } = inventoryLocationSlice.actions;
export default inventoryLocationSlice.reducer;
