import { createSlice } from "@reduxjs/toolkit";

const customerSlice = createSlice({
  name: "customer",
  initialState: {
    customer: [],
  },
  reducers: {
    addCustomerData: (state, action) => {
      state.customer = action.payload;
    },
    clerCustomerData: (state) => {
      state.customer = null;
    },
  },
});

export const { addCustomerData, clerCustomerData } = customerSlice.actions;
export default customerSlice.reducer;
