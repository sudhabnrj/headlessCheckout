import { createSlice } from "@reduxjs/toolkit";

const emailSlice = createSlice({
  name: "email",
  initialState: {
    email: sessionStorage.getItem("email") || "",
  },
  reducers: {
    setEmail: (state, action) => {
      state.email = action.payload;
      sessionStorage.setItem("email", action.payload);
    },
    editEmail: (state, action) => {
      state.email = action.payload; // or your logic
    },
    clearEmail: (state) => {
      state.email = "";
      sessionStorage.removeItem("email");
    },
  },
});

export const { setEmail, clearEmail, editEmail } = emailSlice.actions;
export default emailSlice.reducer;
