import { createSlice } from "@reduxjs/toolkit";

const paymentSlice = createSlice({
  name: "payment",
  initialState: {
    paymentMethod: null,
    isPaymentFetched: false,
  },
  reducers: {
    setPaymentMethods: (state, action) => {
      state.paymentMethods = action.payload;
      state.isPaymentFetched = true;
    },
    resetPaymentState: (state) => {
      state.paymentMethods = [];
      state.isPaymentFetched = false;
    },
  },
});

export const { setPaymentMethods } = paymentSlice.actions;
export default paymentSlice.reducer;
