import { createSlice } from "@reduxjs/toolkit";

const errorSlice = createSlice({
  name: "error",
  initialState: {
    generalError: null,
    customerError: null,
    paymentError: null,
    shippingError: null,
    billingError: null,
    cartError: null,
  },
  reducers: {
    setGeneralError: (state, action) => {
      state.generalError = action.payload;
    },
    setCustomerError: (state, action) => {
      state.customerError = action.payload;
    },
    setShippingError: (state, action) => {
      state.shippingError = action.payload;
    },
    setBillingError: (state, action) => {
      state.billingError = action.payload;
    },
    setPaymentError: (state, action) => {
      state.paymentError = action.payload;
    },
    setCartError: (state, action) => {
      state.cartError = action.payload;
    },
    clearPaymentError: (state) => {
      state.paymentError = null;
    },
    clearShippingError: (state) => {
      state.shippingError = null;
    },
    clearGeneralError: (state) => {
      state.generalError = null;
    },
    clearCustomerError: (state) => {
      state.customerError = null;
    },
    clearBillingError: (state) => {
      state.customerError = null;
    },
    clearCartError: (state) => {
      state.cartError = null;
    },
  },
});

export const {
  setGeneralError,
  setCustomerError,
  setPaymentError,
  setShippingError,
  setBillingError,
  setCartError,

  clearPaymentError,
  clearShippingError,
  clearGeneralError,
  clearCustomerError,
  clearBillingError,
  clearCartError,
} = errorSlice.actions;
export default errorSlice.reducer;
