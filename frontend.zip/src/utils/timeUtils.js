export const getFirstOpenDayHours = (hoursObj = {}) => {
  for (const day of Object.keys(hoursObj)) {
    const dayInfo = hoursObj[day];
    if (dayInfo?.open) {
      return {
        opening: dayInfo.opening,
        closing: dayInfo.closing,
      };
    }
  }
  return { opening: "", closing: "" };
};
