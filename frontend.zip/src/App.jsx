/* eslint-disable react-hooks/exhaustive-deps */
import "../src/styles/App.css";
import Header from "./components/Header";
import Container from "./components/ui/Container";
import CartSidebar from "./components/CartSidebar";
import { useLocation, useNavigate } from "react-router-dom";
import { useEffect, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import Title from "./components/ui/Title";
import Button from "./components/ui/Button";
import ShippingAddressForm from "./components/ShippingAddressForm";
import ShippingOptions from "./components/ShippingOptions";
import RadioButton from "./components/ui/RadioButton";
import { API_URL } from "./lib/constant";
import {
  addCheckoutData,
  resetCheckout,
  setCheckoutError,
  setSelectedPickupOption,
  setSelectedRadioButton,
  setSelectedShippingOption,
} from "./redux/checkoutSlice";
import BillingAddressForm from "./components/BillingAddressForm";
import { createBillingAddress } from "./lib/createBillingAddress";
// import PaymentTab from "./components/PaymentTab";
import VisaIcon from "./components/ui/VisaIcon";
import MasterCardIcon from "./components/ui/MasterCardIcon";
import DiscoverIcon from "./components/ui/DiscoverIcon";
import AmericanExpressIcon from "./components/ui/AmericanExpressIcon";
import { TiLockClosed } from "react-icons/ti";
import Input from "./components/ui/Input";
import Label from "./components/ui/Label";
import GetPaymentMethod from "./lib/GetPaymentMethod";
import { FetchGeoLocation } from "./lib/FetchGeoLocation";
import useDebouncedGeoFetch from "./hooks/useDebouncedGeoFetch";
import { fetchPickupOptions } from "./lib/fetchPickupOptions";
import { handleShippingAndPickup } from "./lib/handleShippingAndPickup";
import { clearEmail, editEmail, setEmail } from "./redux/emailSlice";
import { Validate } from "./lib/Validate";
import { placeOrder } from "./lib/placeOrder";
import EmailForm from "./components/EmailForm";
import ShippingAddress from "./components/ShippingAddress";
import BillingAddress from "./components/BillingAddress";
import { updateBillingAddressAPI } from "./lib/updateBillingAddress";
import { updateShippingAddress } from "./lib/updateShippingAddress";
import { fetchShippingOptions } from "./lib/fetchShippingOptions";
import { updateShippingMethod } from "./lib/updateShippingMethod";
import { getPaymentAccessToken } from "./lib/getPaymentAccessToken";
import { processPayment } from "./lib/processPayment";
import { createEventForPickup } from "./lib/createEventForPickup";
import Checkbox from "./components/ui/Checkbox";
import { getAllPickupLocation } from "./lib/getAllPickupLocation";
import { fetchUpdatedCheckout } from "./lib/fetchUpdatedCheckout";
import { clearCart } from "./redux/cartSlice";
import { getCustomerAddress } from "./lib/getCustomerAddress";
import { GoTriangleDown } from "react-icons/go";

import {
  clearBillingError,
  clearCustomerError,
  clearPaymentError,
  clearShippingError,
  setBillingError,
  setCustomerError,
  setPaymentError,
  setShippingError,
} from "./redux/errorSlice";
import { fetchCustomerShippingAndPickupOptions } from "./lib/fetchCustomerShippingAndPickup";
import BraintreePayPal from "./components/BraintreePayPal";
import CustomerTab from "./components/CustomerTab";
import AddressDropdown from "./components/AddressDropdown";
import PickupInfoBox from "./components/PickupInfoBox";
import CreditCardForm from "./components/CreditCardForm";
import PickupOptionCard from "./components/PickupOptionCard";
import { isEqual } from "lodash";
import {
  FaCcVisa,
  FaCcMastercard,
  FaCcAmex,
  FaCcDiscover,
  FaCcPaypal,
} from "react-icons/fa";
import LoadingSpin from "./components/ui/LoadingSpin";
import { loginBigCommerceUser } from "./components/auth/bigcommerceLoginAuth";
import { addCustomerData } from "./redux/customerSlice";
import { getCheckoutToken } from "./lib/getCheckoutToken";

const useQuery = () => new URLSearchParams(useLocation().search);

function App() {
  // const isLoading = useSelector((state) => state.loader.loading);
  // const errorMessage = useSelector((state) => state.error.message);
  // const generalError = useSelector((state) => state.error.generalError);
  const customerError = useSelector((state) => state.error.customerError);
  const paymentError = useSelector((state) => state.error.paymentError);
  const shippingError = useSelector((state) => state.error.shippingError);
  // const billingError = useSelector((state) => state.error.billingError);
  const { checkoutError } = useSelector((state) => state.checkout);

  const updatedCheckoutResult =
    useSelector((store) => store.checkout.checkoutData) || {};
  const checkoutResult =
    useSelector((store) => store.checkout.checkoutData) || {};
  const customerDetails = useSelector((state) => state.customer.customer) || [];
  const availableShippingOptions = useSelector(
    (state) => state.checkout.availableShippingOptions
  );
  const availablePickupOptions = useSelector(
    (state) => state.checkout.availablePickupOptions
  );
  const error = useSelector((state) => state.error?.error);
  const email = useSelector((state) => state.email.email);
  const updatedBilling_address =
    useSelector((state) => state.checkout.checkoutData) || {};
  const paymentMethods =
    useSelector((state) => state.payment.paymentMethods) || [];

  const { isPaymentFetched } = useSelector((state) => state.payment);

  const updatedStoreLocation =
    useSelector((state) => state.storeLocation.storeLocationData) || {};

  const selectedRadioButton = useSelector(
    (state) => state.checkout.selectedRadioButton
  );
  const selectedPickupOption = useSelector(
    (state) => state.checkout.selectedPickupOption
  );
  const selectedShippingOption = useSelector(
    (state) => state.checkout.selectedShippingOption
  );

  const [loading, setLoading] = useState({
    shipping: false,
    billing: false,
    payment: false,
    customer: false,
  });
  const [selectedPaymentMethod, setSelectedPaymentMethod] =
    useState("braintree.card");

  const [geoLocation, setGeoLocation] = useState(null);
  const [custEmail, setCustEmail] = useState(email || "");
  const [password, setPassword] = useState("");
  const [isSigningIn, setIsSigningIn] = useState(false);
  const [isEmailEditing, setIsEmailEditing] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isBillingEditing, setIsBillingEditing] = useState(false);
  const [isShippingEditing, setIsShippingEditing] = useState(false);
  const [sameAsShipping, setSameAsShipping] = useState(true);
  const [successMessage, setSuccessMessage] = useState(null);

  const [cardNumber, setCardNumber] = useState("");
  const [cardType, setCardType] = useState("");
  const [expiry, setExpiry] = useState("");
  const [cvv, setCvv] = useState("");
  const [cardHolderName, setCardHolderName] = useState("");
  const dropInInstance = useRef(null);
  const [isAddressOpen, setIsAddressOpen] = useState(false);
  const dropdownRef = useRef();
  const [selectedAddress, setSelectedAddress] = useState(null);
  const [showAddressForm, setShowAddressForm] = useState(false);
  const [isCheckoutToken, setIsCheckoutToken] = useState(null);

  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    companyName: "",
    phoneNumber: "",
    address: "",
    apartment: "",
    city: "",
    country: "",
    state: "",
    postalCode: "",
  });
  const [billingFormData, setBillingFormData] = useState({
    firstName: "",
    lastName: "",
    companyName: "",
    phoneNumber: "",
    address: "",
    apartment: "",
    city: "",
    country: "",
    state: "",
    postalCode: "",
  });

  const dispatch = useDispatch();
  const navigate = useNavigate();

  const query = useQuery();
  const checkoutID = query.get("cartId");

  useEffect(() => {
    const init = async () => {
      if (!checkoutID) {
        dispatch(setCheckoutError("Checkout ID is not valid"));
        setTimeout(() => {
          window.location.href = `${import.meta.env.VITE_BC_STORE_URL}`;
        }, 300);
        return;
      }

      try {
        // Fetch the updated checkout
        await fetchUpdatedCheckout(dispatch, checkoutID);

        // Then get the checkout token
        const checkoutToken = await getCheckoutToken(checkoutID);
        // console.log("Checkout Token:", checkoutToken);
        if (checkoutToken) {
          localStorage.setItem("checkoutToken", checkoutToken);
        } else {
          console.warn("Checkout token was null.");
        }
      } catch (error) {
        console.error("Error in checkout useEffect:", error);
        dispatch(
          setCheckoutError(
            "Something went wrong while fetching checkout token."
          )
        );
      }
    };

    init();
  }, [checkoutID, dispatch]);

  const customerID = checkoutResult?.data?.cart?.customer_id || null;

  useEffect(() => {
    if (customerID) {
      getCustomerAddress(dispatch, customerID, setLoading);
    }
  }, [customerID, dispatch]);

  useEffect(() => {
    if (customerDetails.length > 0) {
      setSelectedAddress(customerDetails[0]); // Set default address
    }
  }, [customerDetails]);

  const openAddressDropdown = () => {
    setIsAddressOpen((prev) => !prev);
  };
  useEffect(() => {
    if (customerID && selectedAddress) {
      fetchCustomerShippingAndPickupOptions(
        selectedAddress,
        email,
        API_URL,
        checkoutID,
        cartItems,
        dispatch,
        setLoading
      );
    }
  }, [customerID, selectedAddress]);

  const handleSelectAddress = (address) => {
    setSelectedAddress(address);
    setIsAddressOpen(false);
    if (customerID) {
      fetchCustomerShippingAndPickupOptions(
        address,
        email,
        API_URL,
        checkoutID,
        cartItems,
        dispatch,
        setLoading
      );
    }
  };

  //Shipping option change Radio button
  const handleShippingOptionChange = (shipping) => {
    dispatch(setSelectedShippingOption(shipping));
  };
  //Pickup Option change radio button
  const handlePickupOptionChange = (pickupMethod) => {
    dispatch(setSelectedPickupOption(pickupMethod.pickup_method));
    dispatch(setSelectedRadioButton(pickupMethod.pickup_method.id));
  };
  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsAddressOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const handleOpenAdressForm = () => {
    console.log("Form Open");
    setIsAddressOpen(false);
    setShowAddressForm(true);
    setFormData({});
  };

  const cartItems =
    checkoutResult?.data?.cart?.line_items?.physical_items || [];

  //Fetch geolocation
  const geoLocationData = useDebouncedGeoFetch(formData, 1000);
  const prevGeoLocation = useRef(null);

  // Fetch shipping methods when geoLocation is available
  useEffect(() => {
    if (!geoLocationData || !cartItems.length) return;

    // Prevent duplicate API calls (only call if geoLocationData is different)
    if (isEqual(geoLocationData, prevGeoLocation.current)) return;

    prevGeoLocation.current = geoLocationData; // Update previous value

    const fetchOptions = async () => {
      console.log("Calling fetchShippingOptions...");
      try {
        await fetchShippingOptions(
          email,
          API_URL,
          checkoutID,
          formData,
          cartItems,
          geoLocation,
          dispatch,
          setLoading
        );
        await fetchPickupOptions(
          geoLocationData,
          cartItems,
          dispatch,
          setLoading
        );
      } catch (error) {
        const errorMessage =
          error?.details?.title ||
          error?.message ||
          "Error fetching pickup options. Please try again.";

        dispatch(setShippingError(errorMessage));
      } finally {
        setLoading((prev) => ({ ...prev, shipping: false }));
      }
    };

    fetchOptions();

    // const fetchPickupOnly = async () => {
    //   try {
    //     await fetchPickupOptions(
    //       geoLocationData,
    //       cartItems,
    //       dispatch,
    //       setLoading
    //     );
    //   } catch (error) {
    //     const errorMessage =
    //       error?.details?.title ||
    //       error?.message ||
    //       "Error fetching pickup options. Please try again.";

    //     dispatch(setShippingError(errorMessage));
    //   } finally {
    //     setLoading(false);
    //   }
    // };

    // fetchPickupOnly();
  }, [geoLocationData, cartItems]);

  // Billing address copy from shipping checkbox
  const handleCheckboxChange = () => {
    setSameAsShipping((prev) => {
      // console.log("Checkbox checked:", !prev);
      return !prev;
    });
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleChangeBillingForm = (e) => {
    const { name, value } = e.target;
    setBillingFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const customerEmail = checkoutResult?.data?.cart?.email || null;

  useEffect(() => {
    if (customerID) {
      dispatch(setEmail(customerEmail));
    } else if (email && isEmailEditing) {
      setCustEmail(email);
    }
  }, [customerEmail, email, isEmailEditing]);

  const handleEmailChange = (e) => {
    setCustEmail(e.target.value);
  };
  const handlePasswordChange = (e) => {
    setPassword(e.target.value);
  };
  const handleEmailSubmit = (e) => {
    e.preventDefault();
    setLoading((prev) => ({ ...prev, customer: true }));
    dispatch(clearCustomerError());
    const errors = Validate({ email: custEmail.trim() }, true); // Pass email for validation

    if (errors.email) {
      dispatch(
        setCustomerError(error || "Invalid email address. Please try again.")
      );
      setLoading((prev) => ({ ...prev, customer: false }));

      return;
    }
    setTimeout(() => {
      dispatch(setEmail(custEmail));
      setIsEmailEditing(false);
      setLoading((prev) => ({ ...prev, customer: false }));
    }, 500);
  };

  const handleEditEmail = () => {
    setIsEmailEditing(true);
    setCustEmail(email);
  };

  //Select first time shipping method
  useEffect(() => {
    if (availableShippingOptions?.length > 0 && !selectedRadioButton) {
      dispatch(setSelectedRadioButton(availableShippingOptions[0].id));
    }
  }, [availableShippingOptions]); // Runs when shipping options update

  //Submit Shipping method or Pickup Method with Consignment creation
  const createShippingConsignment = async () => {
    setLoading((prev) => ({ ...prev, shipping: true }));
    dispatch(clearShippingError());

    try {
      const { firstName, lastName, address, city, country, state, postalCode } =
        formData;

      if (
        !firstName ||
        !lastName ||
        !address ||
        !city ||
        !country ||
        !postalCode
      ) {
        dispatch(
          setShippingError("Please complete the shipping address form.")
        );
        return;
      }

      const geoLocation = await FetchGeoLocation(
        address,
        city,
        state,
        postalCode,
        country
      );

      await fetchShippingOptions(
        email,
        API_URL,
        checkoutID,
        formData,
        cartItems,
        geoLocation,
        dispatch,
        setLoading
      );

      await fetchPickupOptions(geoLocation, cartItems, dispatch, setLoading);

      await handleShippingAndPickup(
        selectedRadioButton,
        availableShippingOptions,
        checkoutID,
        event,
        dispatch,
        addCheckoutData,
        checkoutResult
      );

      const updatedCheckoutState = await fetchUpdatedCheckout(
        dispatch,
        checkoutID
      );
      if (!updatedCheckoutState?.data) {
        dispatch(
          setShippingError("Failed to retrieve updated checkout state.")
        );
        return;
      }

      let updatedBillingData = null;
      if (sameAsShipping) {
        await updateBillingData();
        updatedBillingData = await dispatch(
          createBillingAddress(formData, checkoutID, email, checkoutResult)
        );
        setIsBillingEditing(false);
        await GetPaymentMethod(checkoutID, dispatch, setLoading);
      }

      dispatch(
        addCheckoutData({
          ...updatedCheckoutState,
          data: {
            ...updatedCheckoutState.data,
            billing_address:
              updatedBillingData || updatedCheckoutState.data.billing_address,
          },
        })
      );

      setIsSubmitted(true);
    } catch (error) {
      const errorMessage =
        error?.details?.title || error?.message || "Error submitting data.";
      dispatch(setShippingError(errorMessage));
      throw new Error(errorMessage);
    } finally {
      setLoading((prev) => ({ ...prev, shipping: false }));
    }
  };

  //sync selected shiiping / pickup option
  useEffect(() => {
    setLoading((prev) => ({ ...prev, shipping: true }));

    const consignmentData = checkoutResult?.data?.consignments?.[0];

    // If pickup options are available and a pickup method is selected in consignment
    if (
      consignmentData?.selected_pickup_option &&
      availablePickupOptions.length > 0
    ) {
      const selectedPickup = availablePickupOptions.find(
        (pickupData) =>
          pickupData?.pickup_method?.id ===
          consignmentData?.selected_pickup_option?.pickup_method_id
      );

      if (selectedPickup?.pickup_method) {
        dispatch(setSelectedPickupOption(selectedPickup.pickup_method));
        dispatch(setSelectedRadioButton(selectedPickup.pickup_method.id));
      } else {
        // Clear if selected pickup method not found
        dispatch(setSelectedPickupOption(null));
        dispatch(setSelectedRadioButton(null));
      }

      setLoading((prev) => ({ ...prev, shipping: false }));
      return;
    }

    // If a shipping method is selected in consignment
    if (
      consignmentData?.selected_shipping_option &&
      availableShippingOptions.length > 0
    ) {
      const selectedShipping = availableShippingOptions.find(
        (s) => s.id === consignmentData.selected_shipping_option.id
      );

      if (selectedShipping) {
        dispatch(setSelectedShippingOption(selectedShipping));
        dispatch(setSelectedRadioButton(selectedShipping.id));
      } else {
        // Clear if selected shipping not found
        dispatch(setSelectedShippingOption(null));
        dispatch(setSelectedRadioButton(null));
      }

      setLoading((prev) => ({ ...prev, shipping: false }));
      return;
    }

    // If no pickup or shipping option is selected
    setLoading((prev) => ({ ...prev, shipping: false }));
  }, [
    checkoutResult,
    availablePickupOptions,
    availableShippingOptions,
    dispatch,
  ]);

  // ✅ Use `useEffect` to ensure formData is updated before usage
  useEffect(() => {
    if (sameAsShipping && customerID && selectedAddress) {
      console.log("Copying shipping address to billing...");
      setFormData({
        email,
        country: selectedAddress?.country_iso2,
        firstName: selectedAddress?.first_name,
        lastName: selectedAddress?.last_name,
        companyName: selectedAddress?.company || "",
        address: selectedAddress?.street_1,
        apartment: selectedAddress?.street_2 || "",
        city: selectedAddress?.city,
        state: selectedAddress?.state,
        postalCode: selectedAddress?.zip,
        phoneNumber: selectedAddress?.phone || "",
      });
    }
  }, [sameAsShipping, customerID, selectedAddress]);

  const updateBillingData = async () => {
    return new Promise((resolve) => {
      setFormData((prev) => {
        const updatedData = {
          ...prev,
          email,
          country: selectedAddress?.country_iso2,
          firstName: selectedAddress?.first_name,
          lastName: selectedAddress?.last_name,
          companyName: selectedAddress?.company || "",
          address: selectedAddress?.street_1,
          apartment: selectedAddress?.street_2 || "",
          city: selectedAddress?.city,
          state: selectedAddress?.state,
          postalCode: selectedAddress?.zip,
          phoneNumber: selectedAddress?.phone || "",
        };
        resolve(updatedData);
        return updatedData;
      });
    });
  };

  const { shipping_address, selected_shipping_option, selected_pickup_option } =
    checkoutResult?.data?.consignments[0] || {};

  const billingAddress =
    updatedBilling_address?.data?.billing_address?.data?.billing_address || // Case 1: After form submission
    updatedBilling_address?.data?.billing_address; // Case 2: After reloading

  const addressID = billingAddress?.id || null;
  // const consignmentID =
  //   checkoutResult?.data?.consignments &&
  //   Array.isArray(checkoutResult?.data?.consignments)
  //     ? checkoutResult?.data?.consignments[0]?.id
  //     : null;

  //Populate Billing form after Clicking Edit
  useEffect(() => {
    if (billingAddress) {
      setBillingFormData({
        firstName: billingAddress.first_name,
        lastName: billingAddress.last_name,
        companyName: billingAddress.company,
        phoneNumber: billingAddress.phone,
        address: billingAddress.address1,
        apartment: billingAddress.address2,
        city: billingAddress.city,
        country: billingAddress.country_code,
        state: billingAddress.state_or_province,
        postalCode: billingAddress.postal_code,
      });
    }
  }, [billingAddress]);

  useEffect(() => {
    if (selected_pickup_option) {
      getAllPickupLocation(dispatch);
    }
  }, [selected_pickup_option]);

  //Create Billing Form
  const handleBillingForm = async (e) => {
    e.preventDefault();
    setLoading((prev) => ({ ...prev, billing: true }));
    // setIsError(null);
    dispatch(clearBillingError());

    // Ensure all required fields are present
    const { address, city, country, state, postalCode } = billingFormData;

    if (!address || !city || !country || !state || !postalCode) {
      dispatch(setBillingError("Please fill in all required fields."));
      // setIsError("Please fill in all required fields.");
      setLoading((prev) => ({ ...prev, billing: false }));
      return;
    }

    try {
      let updatedBillingData;
      if (billingAddress && Object.keys(billingAddress).length > 0) {
        updatedBillingData = await updateBillingAddressAPI(
          checkoutID,
          addressID,
          email,
          billingFormData
        );
      } else {
        updatedBillingData = await dispatch(
          createBillingAddress(
            billingFormData,
            checkoutID,
            email,
            checkoutResult
          )
        );
      }

      // Update Redux store
      dispatch(
        addCheckoutData({
          ...checkoutResult,
          data: {
            ...checkoutResult.data,
            billing_address: updatedBillingData,
          },
        })
      );

      console.log("Billing address updated successfully.");
      setIsBillingEditing(false); // Hide the form after successful update

      // setStep(3);
      await GetPaymentMethod(checkoutID, dispatch, setLoading);

      // Navigate to the next step or update UI state
    } catch (error) {
      dispatch(
        setBillingError(
          error?.message || "Something went wrong. Please try again."
        )
      );
      // console.error(error.message || "Something went wrong. Please try again.");
    } finally {
      setLoading((prev) => ({ ...prev, billing: false })); // Ensure loading state is reset
    }
  };

  //Paymnt method Load
  useEffect(() => {
    const billingAddressExists =
      checkoutResult?.data?.billing_address ||
      checkoutResult?.data?.billing_address.length > 0;

    const hasDeliveryOption =
      selected_shipping_option || selected_pickup_option;

    if (
      checkoutID &&
      billingAddressExists &&
      hasDeliveryOption &&
      !isPaymentFetched
    ) {
      GetPaymentMethod(checkoutID, dispatch, setLoading);
    }
  }, [
    checkoutID,
    checkoutResult?.data?.billing_address?.length,
    selected_shipping_option,
    selected_pickup_option,
  ]);

  //Save Shipping Address after click on edit button
  const handleUpdateShippingAddress = async (e) => {
    if (e) e.preventDefault();
    setLoading((prev) => ({ ...prev, shipping: true }));
    // setIsError(null);
    dispatch(clearShippingError());

    try {
      // Fetch latest checkout details (including the updated consignment ID)
      const updatedCheckoutRes = await fetch(
        `${API_URL}/checkouts/${checkoutID}`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            "X-Auth-Token": import.meta.env.VITE_APP_ACCESS_TOKEN,
          },
        }
      );

      if (!updatedCheckoutRes.ok) {
        throw new Error("Failed to fetch updated checkout details");
      }

      const updatedCheckoutData = await updatedCheckoutRes.json();

      console.log("updatedCheckoutRes", updatedCheckoutData?.data);

      const latestConsignmentID =
        updatedCheckoutData?.data?.consignments?.[0]?.id; // Get latest consignment ID

      // console.log("updatedCheckoutRes", latestConsignmentID);

      if (!latestConsignmentID) {
        dispatch(setShippingError("Updated consignment ID not found"));
        // throw new Error("Updated consignment ID not found");
      }

      const cartItems =
        updatedCheckoutData?.data?.cart?.line_items?.physical_items?.map(
          (item) => ({
            item_id: item.item_id || item.id, // Ensure `id` exists
            quantity: item.quantity, // Ensure `quantity` exists
          })
        );

      if (!cartItems.length) {
        dispatch(setShippingError("No valid line items found"));
        // console.error("No valid line items found");
        return;
      }

      const selectedMethod = selectedRadioButton;

      // Now update the shipping address using the latest consignment ID
      await updateShippingAddress({
        checkoutID,
        email,
        consignmentID: latestConsignmentID, // Use the updated ID
        API_URL,
        formData,
        cartItems,
        dispatch,
        addCheckoutData,
      });
      if (selectedRadioButton) {
        await updateShippingMethod({
          checkoutID,
          consignmentID: latestConsignmentID,
          API_URL,
          selectedShippingMethod: selectedMethod,
          cartItems,
          dispatch,
          addCheckoutData,
        });
      } else {
        console.warn("⚠️ No valid shipping or pickup method selected.");
      }

      // Step 2: Fetch the latest checkout state from Redux
      const updatedCheckoutState = await fetchUpdatedCheckout(
        dispatch,
        checkoutID
      );

      // console.log("Updated Checkout State:", updatedCheckoutState);

      if (!updatedCheckoutState?.data) {
        dispatch(
          setShippingError(
            "Failed to retrieve updated checkout state, using previous data."
          )
        );
        // console.error(
        //   "Failed to retrieve updated checkout state, using previous data."
        // );
        return;
      }

      let updatedBillingData = null;

      if (sameAsShipping) {
        // console.log("calling billing form ....");
        // console.log(formData);
        const { address, city, country, state, postalCode } = formData;
        if (!address || !city || !country || !state || !postalCode) {
          // setIsError("Required shipping address is missing");
          dispatch(setShippingError("Required shipping address is missing"));
          setLoading((prev) => ({ ...prev, shipping: false }));
          return;
        }

        updatedBillingData = await dispatch(
          createBillingAddress(formData, checkoutID, email, checkoutResult)
        );

        // console.log("updatedBillingData", updatedBillingData);

        setIsBillingEditing(false);

        // setStep(3);
        await GetPaymentMethod(checkoutID, dispatch, setLoading);
      }

      dispatch(
        addCheckoutData({
          ...updatedCheckoutState,
          data: {
            ...updatedCheckoutState.data, // Keep latest checkout data
            billing_address:
              updatedBillingData || updatedCheckoutState.data.billing_address, // Only update billing
          },
        })
      );

      console.log(updatedCheckoutData?.data);

      setIsShippingEditing(false);
    } catch (error) {
      const errorMessage =
        error?.details?.title ||
        error?.message ||
        "Error updating shipping method. Please try again.";

      dispatch(setShippingError(errorMessage));
      throw new Error(errorMessage);
      // console.error("Error updating shipping:", error);
      // setIsError(error.message);
    } finally {
      setLoading((prev) => ({ ...prev, shipping: false }));
    }
  };

  const handlePaymentDropdown = (e) => {
    setSelectedPaymentMethod(e.target.id);
  };

  // console.log("getAllPickupLocation:", updatedStoreLocation?.data);
  // console.log("selectedPickupOption:", selectedPickupOption);
  const filterPickupLocation = Array.isArray(updatedStoreLocation?.data)
    ? updatedStoreLocation.data.filter(
        (store) => store?.id === selectedPickupOption?.location_id
      )
    : [];
  // console.log("filterPickupLocation:", filterPickupLocation);

  const storeEmail = filterPickupLocation[0]?.address?.email;

  //Generate Checkout Token
  useEffect(() => {
    const generateCheckoutToken = async (checkoutID) => {
      try {
        const checkoutToken = await getCheckoutToken(checkoutID);
        console.log(checkoutToken);
      } catch (error) {
        console.error("unable to fetch chckout token", error.message);
      }
    };
    generateCheckoutToken();
  }, []);

  const handlePlaceOrder = async (e) => {
    e.preventDefault();
    // ✅ Loading only after all validations pass
    setLoading((prev) => ({ ...prev, payment: true }));
    dispatch(clearPaymentError());
    setSuccessMessage(null);

    // Validate if payment method is selected
    if (!selectedPaymentMethod) {
      dispatch(setPaymentError("Please select a payment method."));
      return;
    }

    let paymentInstrument = null;

    // If PayPal is selected
    if (selectedPaymentMethod === "braintree.paypal") {
      if (!dropInInstance.current) {
        dispatch(setPaymentError("PayPal payment instance not initialized."));
        return;
      }

      try {
        const { nonce } = await dropInInstance.current.requestPaymentMethod();
        paymentInstrument = {
          payment: {
            instrument: {
              type: "paypal",
              nonce,
            },
            payment_method_id: selectedPaymentMethod,
          },
        };
      } catch (error) {
        const errorMessage =
          error?.details?.title ||
          error?.message ||
          "Failed to process PayPal payment.";
        dispatch(setPaymentError(errorMessage));
        return;
      }
    } else {
      // Validate credit card inputs
      const paymentFields = { cardNumber, expiry, cardHolderName, cvv };
      const paymentValidationErrors = Validate(paymentFields, false, true);

      if (Object.keys(paymentValidationErrors).length > 0) {
        dispatch(
          setPaymentError(Object.values(paymentValidationErrors).join(", "))
        );
        return;
      }

      const [expiryMonth, expiryYear] = expiry.split("/");

      paymentInstrument = {
        payment: {
          instrument: {
            type: "card",
            number: cardNumber,
            cardholder_name: cardHolderName,
            expiry_month: parseInt(expiryMonth),
            expiry_year: parseInt(`20${expiryYear}`),
            verification_value: cvv,
          },
          payment_method_id: selectedPaymentMethod,
        },
      };
    }

    try {
      const orderData = await placeOrder(
        checkoutID,
        selectedPaymentMethod,
        // setIsPaymentError,
        setLoading,
        paymentInstrument
      );

      if (orderData?.error) {
        const errorMessage =
          error?.details?.title ||
          error?.message ||
          "Invalid order data. Order ID is missing";
        dispatch(setPaymentError(errorMessage));
        setLoading((prev) => ({ ...prev, payment: false }));
        return;
      }

      const orderID = orderData?.data?.id;

      if (!orderID) {
        throw new Error("Order ID is missing after placeOrder.");
      }

      const accessToken = await getPaymentAccessToken(orderID);

      let paymentProcess;
      try {
        paymentProcess = await processPayment(
          paymentInstrument,
          accessToken,
          dispatch
        );
      } catch (error) {
        const errorMessage =
          error?.title || error?.message || "Payment processing failed.";
        dispatch(setPaymentError(errorMessage));
        throw new Error("Payment processing failed.");
      }

      if (
        paymentProcess?.data?.status === "success" &&
        selected_pickup_option
      ) {
        const cartDetails = checkoutResult?.data?.cart;
        const { grand_total } = checkoutResult?.data || "";

        await createEventForPickup(
          orderID,
          setLoading,
          cartDetails,
          grand_total,
          email,
          storeEmail,
          selectedPickupOption,
          billingAddress
        );

        // dispatch(resetCheckout());
        // dispatch(clearCart());
        // dispatch(clearEmail());
      }

      // dispatch(resetCheckout());
      // dispatch(clearCart());
      // dispatch(clearEmail());

      console.log("orderID", orderID);

      setSuccessMessage("Payment successful! Redirecting...");

      //Optional redirect
      setTimeout(() => {
        const token = localStorage.getItem("checkoutToken");
        window.location.href = `${
          import.meta.env.VITE_BC_STORE_URL
        }order-confirmation/${orderID}?t=${token}`;
      }, 1500);
    } catch (error) {
      const errorMessage =
        error?.details?.title ||
        error?.message ||
        "Failed to place order. try again...";
      dispatch(setPaymentError(errorMessage));
      throw new Error(errorMessage);
    } finally {
      setLoading((prev) => ({ ...prev, payment: false }));
    }
  };

  const handleSignIn = async () => {
    setLoading((prev) => ({ ...prev, customer: true }));
    dispatch(clearCustomerError());

    try {
      const res = await loginBigCommerceUser(
        custEmail,
        password,
        checkoutID,
        dispatch
      );

      if (res?.data?.login?.result === "success") {
        //fetch updated checkout to get customer info
        const updatedCheckoutRes = await fetchUpdatedCheckout(
          dispatch,
          checkoutID
        );

        console.log("updated Checkout Data", updatedCheckoutRes);
      }
    } catch (err) {
      console.error("Login failed", err);
      dispatch(setCustomerError(err?.message));
    } finally {
      setLoading((prev) => ({ ...prev, customer: false }));
    }
  };

  return (
    <>
      <Header />
      <section className="py-4">
        <Container>
          {checkoutError && (
            <div style={{ color: "red", marginTop: "10px" }}>
              {checkoutError}
            </div>
          )}
          <div className="flex justify-between items-start">
            <form className="w-[70%] max-w-[603px] flex flex-col gap-8">
              <CustomerTab
                customerID={customerID}
                email={email}
                custEmail={custEmail || ""}
                password={password}
                isSigningIn={isSigningIn}
                setIsSigningIn={setIsSigningIn}
                customerError={customerError}
                isEmailEditing={isEmailEditing}
                handleEditEmail={handleEditEmail}
                handleEmailChange={handleEmailChange}
                handleEmailSubmit={handleEmailSubmit}
                loading={loading.customer}
                onClick={handleSignIn}
                handlePasswordChange={handlePasswordChange}
              />

              <div className="w-full border-b border-gray-200">
                <>
                  <Title title="Shipping" />
                  {isShippingEditing ? (
                    <>
                      <div className="w-full">
                        <div className="shipping-header mt-5 mb-3">
                          <h3 className="font-semibold font-primary text-primary text-base mb-5">
                            Shipping Address
                          </h3>
                        </div>
                        <ShippingAddressForm
                          formData={formData}
                          handleChange={handleChange}
                        />
                        <div className="mt-5">
                          <Checkbox
                            id="sameAsShipping"
                            label="My billing address is the same as my shipping address."
                            value={sameAsShipping}
                            onChange={handleCheckboxChange}
                          />
                        </div>
                      </div>

                      {/* Shipping Methods */}
                      <div>
                        {availableShippingOptions?.length > 0 ? (
                          <>
                            <h3 className="font-bold font-primary text-primary text-base mb-0 mt-5">
                              Shipping Method
                            </h3>
                            {availableShippingOptions.map((shipping) => (
                              <ShippingOptions
                                key={shipping.id}
                                id={shipping.id}
                                label={shipping.description}
                                checked={selectedRadioButton === shipping.id}
                                onChange={() =>
                                  handleShippingOptionChange(shipping)
                                }
                                shippingCost={`${
                                  checkoutResult?.data?.cart?.currency?.code ===
                                  "USD"
                                    ? "$"
                                    : "₹"
                                }${shipping.cost.toFixed(2)}`}
                              />
                            ))}
                          </>
                        ) : (
                          <div className="checkout-shipping-options border border-gray-300 p-10 w-full bg-[#f5f5f5]">
                            Please enter a shipping address to see shipping
                            quotes.
                          </div>
                        )}

                        {/* Pickup Options (If No Shipping Selected) */}
                        {availablePickupOptions?.length > 0 ? (
                          <>
                            <h3 className="font-bold font-primary text-primary text-base mb-0 mt-5">
                              Pickup Location
                            </h3>
                            {availablePickupOptions.map(
                              (picLocation, index) => (
                                <PickupOptionCard
                                  key={index}
                                  index={index}
                                  picLocation={picLocation}
                                  selectedRadioButton={selectedRadioButton}
                                  onChange={() =>
                                    handlePickupOptionChange(picLocation)
                                  }
                                />
                              )
                            )}
                          </>
                        ) : (
                          <div className="checkout-shipping-options border border-gray-300 p-10 w-full bg-[#f5f5f5]">
                            Pickup method is not Available
                          </div>
                        )}
                      </div>

                      {/* Save or Update Address Button */}
                      <div className="w-full mt-5">
                        {availableShippingOptions.length ||
                        selected_shipping_option ||
                        selected_pickup_option ? (
                          <Button
                            onClick={handleUpdateShippingAddress}
                            type="button"
                            className="min-w-[231px] py-3 px-4"
                            disabled={loading.shipping}
                          >
                            {loading.shipping ? (
                              <LoadingSpin />
                            ) : (
                              "Update Address"
                            )}
                          </Button>
                        ) : null}
                      </div>

                      {/* Error Message */}
                      <div className="w-full">
                        {shippingError && (
                          <p className="text-red-500 mt-2">{shippingError}</p>
                        )}
                      </div>
                    </>
                  ) : (
                    <div className="mt-8">
                      <div className="w-full flex flex-col gap-4">
                        {/* STEP 1: Display Pickup or Shipping Info Box */}
                        {selected_pickup_option &&
                        Object.keys(selected_pickup_option).length > 0 ? (
                          <div className="flex justify-between items-center">
                            <PickupInfoBox
                              loading={loading.shipping}
                              selectedPickupOption={selectedPickupOption}
                            />
                            <Button
                              type="button"
                              onClick={() => setIsShippingEditing(true)}
                              className="!text-primary bg-transparent border border-primary"
                            >
                              Edit
                            </Button>
                          </div>
                        ) : selected_shipping_option ? (
                          <div className="flex justify-between items-center">
                            <ShippingAddress data={shipping_address} />
                            <Button
                              type="button"
                              onClick={() => setIsShippingEditing(true)}
                              className="!text-primary bg-transparent border border-primary"
                            >
                              Edit
                            </Button>
                          </div>
                        ) : (
                          // STEP 2: Default - Show address form/dropdown + checkbox
                          <div
                            className="flex flex-col gap-3"
                            ref={dropdownRef}
                          >
                            <h3 className="font-bold font-primary text-primary text-base mb-0 mt-5">
                              Shipping Address
                            </h3>

                            {showAddressForm ? (
                              <ShippingAddressForm
                                formData={formData}
                                handleChange={handleChange}
                              />
                            ) : customerID &&
                              customerDetails &&
                              customerDetails.length > 0 ? (
                              <AddressDropdown
                                isOpen={isAddressOpen}
                                selectedAddress={selectedAddress}
                                customerDetails={customerDetails}
                                onToggle={openAddressDropdown}
                                onSelectAddress={handleSelectAddress}
                                onOpenForm={handleOpenAdressForm}
                              />
                            ) : (
                              <ShippingAddressForm
                                formData={formData}
                                handleChange={handleChange}
                              />
                            )}

                            <Checkbox
                              id="sameAsShipping"
                              label="My billing address is the same as my shipping address."
                              value={sameAsShipping}
                              onChange={handleCheckboxChange}
                            />
                          </div>
                        )}

                        {/* STEP 3: Show message if no shipping or pickup options available */}
                        {!selected_shipping_option &&
                          !selected_pickup_option &&
                          availableShippingOptions.length === 0 &&
                          availablePickupOptions.length === 0 && (
                            <div className="checkout-shipping-options border border-gray-300 p-10 w-full bg-[#f5f5f5]">
                              Please enter a shipping address to see shipping
                              quotes.
                            </div>
                          )}

                        {/* STEP 4: Shipping Options */}
                        {!selected_shipping_option &&
                          !selected_pickup_option &&
                          availableShippingOptions.length > 0 && (
                            <>
                              <h3 className="font-bold font-primary text-primary text-base mb-0 mt-5">
                                Shipping Method
                              </h3>
                              {availableShippingOptions.map((shipping) => (
                                <ShippingOptions
                                  key={shipping.id}
                                  id={shipping.id}
                                  label={shipping.description}
                                  checked={selectedRadioButton === shipping.id}
                                  onChange={() =>
                                    handleShippingOptionChange(shipping)
                                  }
                                  shippingCost={`${
                                    checkoutResult?.data?.cart?.currency
                                      ?.code === "USD"
                                      ? "$"
                                      : "₹"
                                  }${shipping.cost.toFixed(2)}`}
                                />
                              ))}
                            </>
                          )}

                        {/* STEP 5: Pickup Options */}
                        {!selected_shipping_option &&
                          !selected_pickup_option &&
                          availablePickupOptions.length > 0 && (
                            <>
                              <h3 className="font-bold font-primary text-primary text-base mb-0 mt-5">
                                Pickup Location
                              </h3>
                              {availablePickupOptions.map(
                                (picLocation, index) => (
                                  <PickupOptionCard
                                    key={index}
                                    index={index}
                                    picLocation={picLocation}
                                    selectedRadioButton={selectedRadioButton}
                                    onChange={() =>
                                      handlePickupOptionChange(picLocation)
                                    }
                                  />
                                )
                              )}
                            </>
                          )}

                        {/* STEP 6: Pickup not available message */}
                        {!selected_shipping_option &&
                          !selected_pickup_option &&
                          availablePickupOptions.length === 0 &&
                          availableShippingOptions.length > 0 && (
                            <p className="text-gray-500 mt-2">
                              Pickup method is not available.
                            </p>
                          )}

                        {/* STEP 7: Selected Shipping Summary */}
                        {selected_shipping_option && (
                          <div>
                            <h3 className="font-bold font-primary text-primary text-base mb-0 mt-5">
                              Shipping Method
                            </h3>
                            <hr className="my-2 border-gray-300" />
                            <p className="text-sm text-gray-700">
                              {selected_shipping_option.description}{" "}
                              <span className="font-bold">
                                {checkoutResult?.data?.cart?.currency?.code ===
                                "USD"
                                  ? "$"
                                  : "₹"}
                                {selected_shipping_option.cost.toFixed(2)}
                              </span>
                            </p>
                          </div>
                        )}

                        {/* STEP 8: Continue Button */}
                        <div className="w-full">
                          {!selected_shipping_option &&
                            !selected_pickup_option && (
                              <Button
                                onClick={createShippingConsignment}
                                type="button"
                                className="min-w-[231px] py-3 px-4"
                                disabled={
                                  loading.shipping ||
                                  (availableShippingOptions.length === 0 &&
                                    availablePickupOptions.length === 0)
                                }
                              >
                                {loading.shipping ? (
                                  <LoadingSpin />
                                ) : (
                                  "Continue"
                                )}
                              </Button>
                            )}
                        </div>
                      </div>

                      {/* STEP 9: Error Message */}
                      {shippingError && (
                        <p className="text-red-500 mt-2">{shippingError}</p>
                      )}
                    </div>
                  )}
                </>

                <div className="py-4 border-b border-gray-200">
                  <Title
                    className="mt-10 pt-10 border-t border-gray-300"
                    title="Billing"
                  />
                  {(selected_shipping_option || selected_pickup_option) &&
                    (isBillingEditing ? (
                      <div className="mt-10">
                        <div className="w-full flex flex-col gap-4">
                          <BillingAddressForm
                            billingFormData={billingFormData}
                            handleChange={handleChangeBillingForm}
                          />
                          <div className="w-full mt-5 mb-8">
                            <Button
                              onClick={handleBillingForm}
                              type="button"
                              className="min-w-[231px] py-3 px-4"
                              disabled={loading.billing}
                            >
                              {loading.billing ? <LoadingSpin /> : "Continue"}
                            </Button>
                          </div>
                        </div>
                      </div>
                    ) : billingAddress &&
                      Object.keys(billingAddress).length > 0 &&
                      (billingAddress?.city ||
                        billingAddress?.state_or_province ||
                        billingAddress?.country ||
                        billingAddress?.postal_code) ? (
                      <>
                        <div className="flex justify-between items-center">
                          <BillingAddress data={billingAddress} />
                          <Button
                            type="button"
                            onClick={() => setIsBillingEditing(true)}
                            className={
                              "!text-primary bg-transparent border border-primary "
                            }
                          >
                            Edit
                          </Button>
                        </div>
                      </>
                    ) : (
                      <>
                        <div className="shipping-header mt-5 mb-3">
                          <h3 className="font-semibold font-primary text-primary text-base mb-5">
                            Billing Address
                          </h3>
                        </div>

                        <div className="mt-10">
                          <div className="w-full flex flex-col gap-4">
                            <BillingAddressForm
                              billingFormData={billingFormData}
                              handleChange={handleChangeBillingForm}
                            />
                            <div className="w-full mt-5 mb-8">
                              <Button
                                onClick={handleBillingForm}
                                type="button"
                                className="min-w-[231px] py-3 px-4"
                                disabled={loading.billing}
                              >
                                {loading.billing ? <LoadingSpin /> : "Continue"}
                              </Button>
                            </div>
                          </div>
                        </div>
                      </>
                    ))}
                </div>

                <div className="py-4 rounded-lg mt-4">
                  <Title title={"Payment"} />
                  {paymentMethods.length > 0 && (
                    <div className="w-full ">
                      <div className="mt-8">
                        <div className="accordian border border-gray-300 w-full">
                          {paymentMethods?.map((payment) => (
                            <div
                              key={payment.id}
                              className="accordian-tab bg-gray-100"
                            >
                              {/* Payment Method Selection */}
                              <div className="accordian-header w-full flex justify-between items-center px-4 py-3 border-b border-gray-300 min-h-[81px]">
                                <RadioButton
                                  name="paymentCard"
                                  id={payment.id}
                                  label={`${payment?.name} ${payment?.type}`}
                                  checked={selectedPaymentMethod === payment.id}
                                  onChange={handlePaymentDropdown}
                                />

                                {/* Show Card I<con>s for Manual Payment */}
                                {payment.id === "braintree.card" ? (
                                  <div className="flex justify-end items-center gap-2 mt-2">
                                    <FaCcVisa
                                      className={`w-8 h-8 transition-all ${
                                        cardType === "visa"
                                          ? "text-blue-600 opacity-100 scale-110"
                                          : "text-gray-400 opacity-40"
                                      }`}
                                    />
                                    <FaCcMastercard
                                      className={`w-8 h-8 transition-all ${
                                        cardType === "mastercard"
                                          ? "text-red-600 opacity-100 scale-110"
                                          : "text-gray-400 opacity-40"
                                      }`}
                                    />
                                    <FaCcAmex
                                      className={`w-8 h-8 transition-all ${
                                        cardType === "american-express" ||
                                        cardType === "amex"
                                          ? "text-indigo-600 opacity-100 scale-110"
                                          : "text-gray-400 opacity-40"
                                      }`}
                                    />
                                    <FaCcDiscover
                                      className={`w-8 h-8 transition-all ${
                                        cardType === "discover"
                                          ? "text-orange-500 opacity-100 scale-110"
                                          : "text-gray-400 opacity-40"
                                      }`}
                                    />
                                  </div>
                                ) : (
                                  <div className="flex justify-end items-center gap-2 mt-2">
                                    <FaCcPaypal className="w-8 h-8 transition-all text-blue" />
                                  </div>
                                )}
                              </div>

                              {/* Show Card Fields Only for Manual Payment */}
                              {selectedPaymentMethod === payment.id &&
                                payment.id === "braintree.card" && (
                                  <CreditCardForm
                                    cardNumber={cardNumber}
                                    setCardNumber={setCardNumber}
                                    expiry={expiry}
                                    setExpiry={setExpiry}
                                    cardHolderName={cardHolderName}
                                    setCardHolderName={setCardHolderName}
                                    cvv={cvv}
                                    setCvv={setCvv}
                                    setCardType={setCardType}
                                  />
                                )}
                            </div>
                          ))}
                        </div>
                        {selectedPaymentMethod === "braintree.card" && (
                          <div className="w-full flex flex-col gap-4 mt-6">
                            <Button
                              type="button"
                              onClick={handlePlaceOrder}
                              className="w-full py-3 px-4 uppercase text-xl"
                              disabled={loading.payment}
                            >
                              {loading.payment ? (
                                <LoadingSpin />
                              ) : (
                                "Pay with Card"
                              )}
                            </Button>
                          </div>
                        )}

                        {/* Conditional Payment Button */}
                        {selectedPaymentMethod === "braintree.paypal" && (
                          <div className="w-full flex justify-center items-center">
                            <BraintreePayPal
                              checkoutResult={checkoutResult}
                              pickupLocation={
                                selected_pickup_option
                                  ? filterPickupLocation[0]
                                  : ""
                              }
                              selectedPaymentMethod={selectedPaymentMethod}
                              selectedPickupOption={selectedPickupOption}
                              email={email}
                            />
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                  {paymentError &&
                    (typeof paymentError === "string" ? (
                      paymentError.split(", ").map((error, index) => (
                        <p key={index} className="text-red-500 text-sm">
                          {error}
                        </p>
                      ))
                    ) : (
                      <p className="text-red-500 text-sm">{paymentError}</p>
                    ))}
                  {successMessage && (
                    <p className="text-green-500 mt-2">{successMessage}</p>
                  )}
                </div>
              </div>
            </form>

            <div className="cart-sidebar w-[30%] max-w-[357px]">
              <CartSidebar checkoutID={checkoutID} />
            </div>
          </div>
        </Container>
      </section>
    </>
  );
}

export default App;
