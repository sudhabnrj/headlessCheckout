import React, { useEffect, useState } from "react";
import { API_URL } from "../lib/constant";
import { useDispatch } from "react-redux";
import { addCheckoutData } from "../redux/checkoutSlice";
// import { setLoading } from "../redux/loaderSlice";
import { addCartData } from "../redux/cartSlice";
import { setGeneralError } from "../redux/errorSlice";

const useCheckout = (checkoutID) => {
  const dispatch = useDispatch();

  useEffect(() => {
    const fetchCheckout = async () => {
      try {
        const response = await fetch(`${API_URL}/checkouts/${checkoutID}`);
        if (!response.ok) {
          throw new Error(`Error ${response.status}: ${response.statusText}`);
        }

        const data = await response.json();
        dispatch(addCheckoutData(data));
        dispatch(addCartData(data));

        console.log("updated checkout:", dispatch(addCheckoutData(data)));
      } catch (error) {
        dispatch(
          setGeneralError(
            "Unable to fetch Checkout ID. please try again",
            error
          )
        );
        console.error(error);
      }
    };

    fetchCheckout();
  }, [checkoutID, dispatch]);
};

export default useCheckout;
