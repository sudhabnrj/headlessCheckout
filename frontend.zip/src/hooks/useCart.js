import { useState, useEffect } from "react";
import { API_URL } from "../lib/constant";

const useCart = () => {
  const [cart, setCart] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const getCart = async () => {
      try {
        const response = await fetch(`${API_URL}/carts`);
        if (!response.ok) {
          throw new Error("Unable to fetch Cart Data");
        }
        const data = await response.json();
        // console.log("Cart Data", data);
        setCart(data);
      } catch (error) {
        // console.error(error);
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

    getCart();
  }, []);

  return { cart, loading, error };
};

export default useCart;
