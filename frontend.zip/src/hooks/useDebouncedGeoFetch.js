/* eslint-disable react-hooks/exhaustive-deps */
import { useEffect, useState } from "react";
import { FetchGeoLocation } from "../lib/FetchGeoLocation";

const useDebouncedGeoFetch = (formData, delay = 1000) => {
  const [geoLocation, setGeoLocation] = useState(null);
  const [debouncedFormData, setDebouncedFormData] = useState(formData || {});

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedFormData(formData || {});
    }, [delay]);

    return () => clearTimeout(handler);
  }, [formData, delay]);

  useEffect(() => {
    const {
      address = "",
      city = "",
      state = "",
      postal_code = "",
      country = "",
    } = debouncedFormData || {};

    if (
      address.length >= 4 ||
      city.length >= 3 ||
      state.length >= 4 ||
      postal_code.length >= 4 ||
      country >= 3
    ) {
      FetchGeoLocation(address, city, state, postal_code, country).then(
        (newGeoLocation) => {
          if (JSON.stringify(newGeoLocation) !== JSON.stringify(geoLocation)) {
            setGeoLocation(newGeoLocation); // Update only if different
          }
        }
      );
    }
  }, [debouncedFormData]);

  return geoLocation;
};

export default useDebouncedGeoFetch;
