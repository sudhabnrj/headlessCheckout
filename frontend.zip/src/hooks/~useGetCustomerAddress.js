import { addCustomerData } from "../redux/customerSlice";
import { clearCustomerError } from "../redux/errorSlice";
import { API_URL } from "../lib/constant";
const AUTH_TOKEN = import.meta.env.VITE_APP_ACCESS_TOKEN;
export const useGetCustomerAddress = async (
  dispatch,
  setLoading,
  customerID
) => {
  try {
    setLoading(true);

    const response = await fetch(
      `${API_URL}/customers/${customerID}/addresses`,
      {
        headers: {
          "Content-Type": "application/json",
          "X-Auth-Token": AUTH_TOKEN,
        },
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      console.error("Error response body:", errorText);
      throw new Error(`Failed to fetch Address: ${response.status}`);
    }

    const addressData = await response.json();

    dispatch(addCustomerData(addressData[0]));

    console.log("fetch Customer Address API response", addressData[0]);

    return addressData;
  } catch (error) {
    const errorMessage =
      error?.details?.title ||
      error?.message ||
      "Error fetching Address. Please try again.";
    dispatch(clearCustomerError(errorMessage));
    // console.error(errorMessage);
  } finally {
    setLoading(false);
  }
};
