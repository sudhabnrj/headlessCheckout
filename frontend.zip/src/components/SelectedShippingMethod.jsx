/* eslint-disable react/prop-types */
import React from "react";

const SelectedShippingMethod = ({ selectedShippingOption }) => {
  if (!selectedShippingOption) return null;

  return (
    <>
      <h3 className="font-bold font-primary text-primary text-base mb-0 mt-5">
        Shipping Method
      </h3>
      <div>
        <hr className="my-2 border-gray-300" />
        <p className="text-sm text-gray-700">
          {selectedShippingOption.description}{" "}
          <span className="font-bold">
            ₹{selectedShippingOption.cost.toFixed(2)}
          </span>
        </p>
      </div>
    </>
  );
};

export default SelectedShippingMethod;
