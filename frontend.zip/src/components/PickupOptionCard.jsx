/* eslint-disable react/prop-types */
import React from "react";
import RadioButton from "../components/ui/RadioButton"; // Adjust import path if needed

// import {
//   setSelectedPickupOption,
//   setSelectedRadioButton,
// } from "../redux/checkoutSlice";
// import { useDispatch } from "react-redux";

const PickupOptionCard = ({
  index,
  picLocation,
  selectedRadioButton,
  onChange,
}) => {
  // const dispatch = useDispatch();
  const pickup = picLocation?.pickup_method;

  if (!pickup) return null;

  return (
    <div
      key={index}
      className="checkout-shipping-options border border-gray-300 p-5 w-full bg-[#f5f5f5]"
    >
      <div className="flex justify-between items-center">
        <div className="flex justify-start items-center flex-col gap-4">
          <RadioButton
            name="customMethod"
            data-location_Id={pickup.location_id}
            id={pickup.id}
            label={pickup.display_name}
            description={pickup.collection_instructions}
            checked={selectedRadioButton === pickup.id}
            onChange={onChange}
          />
        </div>
        <div className="shippingCost justify-end items-center">
          <span className="shippingOption-price text-primary font-bold font-primary">
            {pickup.collection_time_description}
          </span>
        </div>
      </div>
    </div>
  );
};

export default PickupOptionCard;
