/* eslint-disable react/prop-types */
import React from "react";
import CartSidebarSkeleton from "./ui/CartSidebarSkeleton";
import { useDispatch, useSelector } from "react-redux";
import useCheckout from "../hooks/useCheckout";
import { Link } from "react-router-dom";
import { useState } from "react";
// import { applyCoupon, clearCoupon } from "../redux/cartSlice";
import { applyCouponCode } from "../lib/applyCouponCode";
import { removeCouponCode } from "../lib/removeCouponCode";
import { setCartError } from "../redux/errorSlice";
import Button from "./ui/Button";

// const useQuery = () => new URLSearchParams(useLocation().search);

const CartSidebar = ({ checkoutID }) => {
  useCheckout(checkoutID);

  const checkoutResult =
    useSelector((store) => store.checkout.checkoutData) || {};
  // const appliedCoupon = useSelector((store) => store.cart.coupon);
  // const isLoading = useSelector((state) => state.loader.loading);
  const cartError = useSelector((state) => state.error.cartError);
  const [isLoading, setIsLoading] = useState(false);
  const [isCouponLoading, setIsCouponLoading] = useState(false);

  const dispatch = useDispatch();

  // Coupon state
  const [showCouponInput, setShowCouponInput] = useState(false);
  const [couponCode, setCouponCode] = useState("");

  const { subtotal_ex_tax, grand_total, tax_total } =
    checkoutResult?.data || {};
  const { currency, line_items } = checkoutResult?.data?.cart || {};

  const { selected_shipping_option } =
    checkoutResult?.data?.consignments[0] || {};
  // const version = checkoutResult?.data?.version || "";

  // console.log("version", version);

  // Function to apply coupon
  const handleApplyCouponCode = async () => {
    setIsCouponLoading(true);
    if (!couponCode.trim()) {
      dispatch(setCartError("Enter a valid coupon code"));
      setIsCouponLoading(false);
      return;
    }
    const response = await applyCouponCode(
      couponCode,
      checkoutID,
      dispatch,
      setIsCouponLoading
    );
    if (response?.error) {
      dispatch(setCartError(response.error)); // Dispatch the error to Redux
      return;
    }
    setShowCouponInput(false);
  };
  const appliedCoupon = checkoutResult?.data?.coupons[0];

  const handleRemoveCouponCode = async () => {
    const response = await removeCouponCode(
      checkoutID,
      appliedCoupon,
      dispatch,
      setIsCouponLoading
    );
    if (response?.error) {
      dispatch(setCartError(response.error)); // Dispatch the error to Redux
      return;
    }
  };

  if (isLoading) {
    return <CartSidebarSkeleton />;
  }

  return (
    <div className="cart-list flex flex-col w-full border rounded-sm border-gray-200 shadow relative">
      {cartError && <div className="text-red-500 p-5">{cartError}</div>}
      <div className="card-header w-full flex justify-between items-center p-5 rounded-none border-b border-gray-200">
        <h3 className="text-base font-semibold text-primary ">Order Summary</h3>
        <Link to={"/"} className="text-blue font-medium capitalize text-[14px]">
          Edit cart
        </Link>
      </div>
      <div className="card-body w-full flex flex-col p-5">
        <p className="text-primary text-[14px] font-primary font-medium mb-4">
          {line_items?.physical_items.length || 0} Items
        </p>
        {line_items?.physical_items &&
          line_items?.physical_items.map((cart) => (
            <div key={cart.id} className="cart-item flex w-full gap-4">
              <figure className="product-column product-figure w-[25%]">
                <img
                  alt={cart?.name}
                  data-test="cart-item-image"
                  src={cart?.image_url}
                />
              </figure>
              <div className="product-column product-body w-1/2">
                <h4 className="product-title text-sm font-medium font-primary text-primary mb-1">
                  {cart?.name}
                </h4>
                <ul className="product-options">
                  <li className="product-option text-[#757575] text-[12px] font-medium font-primary">
                    Size <span>Bar</span>
                  </li>
                </ul>
              </div>
              <div className="product-column product-actions w-[25%] flex justify-end">
                <div className="product-price text-sm font-medium font-primary text-primary">
                  {currency?.code === "INR" ? "₹" : "$"}
                  {cart?.sale_price ? cart?.sale_price.toFixed(2) : "0.00"}
                </div>
              </div>
            </div>
          ))}
      </div>
      <div className="cart-subtotal flex flex-col gap-3 border-t border-gray-200 p-5">
        <div className="cart-priceItem flex justify-between items-center text-primary text-[14px] font-primary font-medium">
          <span>Subtotal</span>
          <span className="cart-price-value">
            {currency?.code === "INR" ? "₹" : "$"}
            {subtotal_ex_tax ? subtotal_ex_tax.toFixed(2) : "0.00"}
          </span>
        </div>
        <div className="cart-priceItem flex justify-between items-center text-primary text-[14px] font-primary font-medium">
          <span>Shipping</span>
          <span className="cart-price-value">
            {selected_shipping_option && selected_shipping_option
              ? `${currency?.code === "INR" ? "₹" : "$"}${
                  selected_shipping_option?.cost
                }`
              : "---"}
          </span>
        </div>
        <div className="cart-priceItem flex justify-between items-center text-primary text-[14px] font-primary font-medium">
          <span>Tax</span>
          <span className="cart-price-value">
            {currency?.code === "INR" ? "₹" : "$"}
            {tax_total}
          </span>
        </div>
        <div className="cart-priceItem flex flex-col text-primary text-[14px] font-primary font-medium">
          {!appliedCoupon ? (
            !showCouponInput ? (
              <button
                type="button"
                className="text-blue text-left cursor-pointer"
                onClick={() => setShowCouponInput(true)}
              >
                Add Coupon/Gift Certificate
              </button>
            ) : (
              <div className="flex gap-2 mt-2">
                <input
                  type="text"
                  placeholder="Enter Coupon Code"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value)}
                  className="border px-3 py-2 w-full rounded"
                />
                <Button
                  type="button"
                  className={`px-4 py-2 rounded cursor-pointer ${
                    isCouponLoading
                      ? "bg-blue-300 cursor-not-allowed"
                      : "bg-blue-500"
                  } text-white`}
                  onClick={handleApplyCouponCode}
                  disabled={isCouponLoading}
                >
                  {isCouponLoading ? "Applying..." : "Apply"}
                </Button>
              </div>
            )
          ) : (
            <div className="text-green-600 font-medium flex flex-col justify-between items-center w-full">
              <div className="flex items-center justify-between w-full">
                <span className="cart-priceItem-label">
                  <span>
                    Coupon Applied
                    {appliedCoupon?.display_name}
                  </span>
                  <span className="cart-priceItem-link">
                    <span
                      onClick={handleRemoveCouponCode}
                      className="ml-2 text-red-600 cursor-pointer"
                    >
                      {isCouponLoading ? "Removing..." : "Remove"}
                    </span>
                  </span>
                </span>
                <span className="text-primary">
                  -{currency?.code === "INR" ? "₹" : "$"}
                  {appliedCoupon?.discounted_amount}
                </span>
              </div>
              <div className="rounded bg-amber-100 text-gray-400 w-full text-center mt-2 px-4 py-2 text-base font-bold">
                {appliedCoupon?.code}
              </div>
            </div>
          )}
        </div>
      </div>
      <div className="cart-total flex justify-between items-center border-t border-gray-200 p-5 text-primary font-primary">
        <span className="cart-price-label text-base font-medium">
          Total ({currency?.code})
        </span>
        <span className="cart-price-value font-bold text-primary text-3xl">
          {currency?.code === "INR" ? "₹" : "$"}
          {grand_total ? grand_total.toFixed(2) : "0.00"}
        </span>
      </div>
    </div>
  );
};

export default CartSidebar;
