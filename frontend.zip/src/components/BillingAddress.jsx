import React from "react";

const BillingAddress = ({ data }) => {
  return (
    <div className="mt-2 text-gray-700">
      <p className="font-medium">{`${data?.first_name} ${data?.last_name}`}</p>
      <p className="text-sm">
        {data?.company} {data?.phone}
      </p>
      <p className="text-sm">
        {data?.country} {`/ ${data?.address2},`}
      </p>
      <p className="text-sm">
        {`${data?.city},`} {`${data?.state_or_province},`}{" "}
        {`${data?.postal_code} /`}
        {data?.country}
      </p>
    </div>
  );
};

export default BillingAddress;
