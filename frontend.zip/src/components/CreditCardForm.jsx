/* eslint-disable react/prop-types */
import React, { useState } from "react";
import { TiLockClosed } from "react-icons/ti";
import Label from "./ui/Label";
import Input from "./ui/Input";
import Cleave from "cleave.js/react";

const CreditCardForm = ({
  cardNumber,
  setCardNumber,
  expiry,
  setExpiry,
  cardHolderName,
  setCardHolderName,
  cvv,
  setCvv,
  setCardType,
}) => {
  const [isBlurred, setIsBlurred] = useState(false);
  const [cvvFocused, setCvvFocused] = useState(true);

  const getMaskedCardNumber = (number) => {
    const clean = number.replace(/\D/g, "");
    if (clean.length < 4) return clean;
    const last4 = clean.slice(-4);
    return `**** **** **** ${last4}`;
  };
  return (
    <div className="accordian-body border-b border-gray-300 p-4">
      <div className="w-full flex justify-between items-center gap-4">
        <div className="flex flex-col w-[80%]">
          <Label label={"Credit Card Number"} />
          <div className="relative">
            {isBlurred ? (
              <input
                type="text"
                className="pr-12 bg-white px-3 py-2 rounded w-full border border-gray-300"
                value={getMaskedCardNumber(cardNumber)}
                onFocus={() => setIsBlurred(false)}
                readOnly
              />
            ) : (
              <Cleave
                placeholder="1234 5678 9012 3456"
                className="pr-12 bg-white px-3 py-2 rounded w-full border border-gray-300"
                value={cardNumber}
                options={{
                  creditCard: true,
                  onCreditCardTypeChanged: (type) => {
                    if (setCardType) setCardType(type);
                  },
                }}
                onChange={(e) => setCardNumber(e.target.rawValue)}
                onBlur={() => setIsBlurred(true)}
              />
            )}
            <span className="absolute top-1 right-2">
              <TiLockClosed className="w-8 h-8 fill-gray-500" />
            </span>
          </div>
        </div>

        <div className="flex flex-col w-[20%]">
          <Label label={"Expiration"} />
          <Cleave
            placeholder="MM/YY"
            className="bg-white px-3 py-2 rounded w-full border border-gray-300"
            value={expiry}
            options={{ date: true, datePattern: ["m", "y"] }}
            onChange={(e) => setExpiry(e.target.value)}
          />
        </div>
      </div>

      <div className="w-full flex justify-between items-center gap-4 mt-5">
        <div className="flex flex-col w-[80%]">
          <Label label={"Name on Card"} />
          <Input
            className="bg-white"
            type="text"
            name="cardHolderName"
            value={cardHolderName}
            onChange={(e) =>
              setCardHolderName(
                e.target.value.replace(/[^A-Za-z\s]/g, "").slice(0, 30)
              )
            }
          />
        </div>

        <div className="flex flex-col w-[20%]">
          <Label label={"CVV"} />
          <div className="relative">
            <Input
              className="bg-white"
              type="text"
              name="cvv"
              placeholder="123"
              value={cvvFocused ? cvv : "*".repeat(cvv.length)}
              onChange={(e) => {
                const input = e.target.value.replace(/\D/g, "").slice(0, 4);
                setCvv(input);
              }}
              onFocus={() => setCvvFocused(true)}
              onBlur={() => setCvvFocused(false)}
            />
            <span className="absolute top-1 right-2">
              <TiLockClosed className="w-8 h-8 fill-gray-500" />
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CreditCardForm;
