/* eslint-disable react/prop-types */
import React, { useState, useEffect } from "react";
import { API_URL } from "../lib/constant";
import Button from "./ui/Button";
import braintree from "braintree-web";
import { useDispatch } from "react-redux";
import { setPaymentError } from "../redux/errorSlice";
import { createPaypalOrder } from "../lib/createPaypalOrder";
import { getFirstOpenDayHours } from "../utils/timeUtils";
import { createEventForPickup } from "../lib/createEventForPickup";
import { resetCheckout } from "../redux/checkoutSlice";
import { clearCart } from "../redux/cartSlice";
import { clearEmail } from "../redux/emailSlice";
import { useNavigate } from "react-router-dom";
import LoadingSpin from "./ui/LoadingSpin";

const BraintreePayPal = ({
  checkoutResult,
  selectedPaymentMethod,
  email,
  pickupLocation,
  selectedPickupOption,
}) => {
  const [clientToken, setClientToken] = useState(null);
  const [loading, setLoading] = useState(false);
  const [isSuccessMessage, setIsSuccessMessage] = useState(null);
  // const paymentError = useSelector((state) => state.error.paymentError);

  const dispatch = useDispatch();
  const navigate = useNavigate();

  const {
    billing_address,
    cart,
    grand_total,
    consignments,
    subtotal_inc_tax,
    subtotal_ex_tax,
  } = checkoutResult?.data || {};

  const { shipping_address, selected_shipping_option, selected_pickup_option } =
    consignments[0] || {};
  const { opening, closing } = getFirstOpenDayHours(
    pickupLocation?.operating_hours
  );

  console.log(pickupLocation);

  //Fetch Client Token on Component Mount || step
  useEffect(() => {
    const fetchClientToken = async () => {
      try {
        const response = await fetch(`${API_URL}/braintree/client-token`);
        const data = await response.json();
        if (data.clientToken) {
          setClientToken(data.clientToken);
        } else {
          dispatch(setPaymentError("No client token received:"));
          console.error("No client token received:", data);
        }
      } catch (error) {
        const errorMessage =
          error?.details?.title ||
          error?.message ||
          "Failed to fetch client token";
        console.error(errorMessage);
      }
    };
    fetchClientToken();
  }, []);

  const handlePayPalPayment = async () => {
    setLoading(true);
    try {
      const clientInstance = await braintree.client.create({
        authorization: clientToken,
      });
      const paypalInstance = await braintree.paypal.create({
        client: clientInstance,
      });

      const payload = await paypalInstance.tokenize({
        flow: "checkout",
        intent: "sale",
        amount: grand_total.toFixed(2),
        currency: "USD",
      });

      console.log("payload.nonce", payload.nonce);

      const response = await fetch(`${API_URL}/braintree/checkout`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          paymentMethodNonce: payload.nonce,
          amount: grand_total.toFixed(2),
        }),
      });

      const data = await response.json();
      if (data.success) {
        setIsSuccessMessage(
          "Payment successful! Transaction ID: " + data.transactionId
        );

        let orderPayload;

        if (selected_pickup_option) {
          orderPayload = {
            customer_id: cart?.customer_id,
            customer_message: "",
            billing_address: {
              first_name: billing_address?.first_name,
              last_name: billing_address?.last_name,
              company: billing_address?.company,
              street_1: billing_address?.address1,
              street_2: billing_address?.address2,
              city: billing_address?.city,
              state: billing_address?.state,
              zip: billing_address?.postal_code,
              country: billing_address?.country,
              country_iso2: billing_address?.country_code,
              phone: billing_address?.phone,
              email,
            },
            default_currency_code: "USD",
            shipping_addresses: [
              {
                first_name: shipping_address?.first_name,
                last_name: shipping_address?.last_name,
                company: shipping_address?.company,
                street_1: shipping_address?.address1,
                street_2: shipping_address?.address2,
                city: shipping_address?.city,
                state: shipping_address?.state,
                zip: shipping_address?.postal_code,
                country: shipping_address?.country,
                country_iso2: shipping_address?.country_code,
                phone: shipping_address?.phone,
                email,
                shipping_method: selected_shipping_option?.description,
              },
            ],
            consignments: {
              pickups: [
                {
                  pickup_method_id: selected_pickup_option?.pickup_method_id,
                  pickup_method_display_name: `Pickup - ${pickupLocation?.label}`,
                  collection_instructions: pickupLocation?.description,
                  collection_time_description: `${opening} - ${closing}`,
                  location: {
                    name: pickupLocation?.label,
                    code: pickupLocation?.code,
                    address_line_1: pickupLocation?.address?.address1,
                    address_line_2: pickupLocation?.address?.address2,
                    city: pickupLocation?.address?.city,
                    state: pickupLocation?.address?.state,
                    postal_code: pickupLocation?.address?.zip,
                    country_alpha2: pickupLocation?.address?.country_code,
                    email: pickupLocation?.address?.email,
                    phone: pickupLocation?.address?.phone,
                  },
                  line_items: cart?.line_items?.physical_items?.map((item) => ({
                    name: item?.name,
                    quantity: item?.quantity,
                    price_inc_tax: item?.list_price,
                    price_ex_tax: item?.list_price,
                    upc: "",
                    sku: item?.sku,
                  })),
                },
              ],
            },
            // base_handling_cost: selected_shipping_option?.cost,
            // base_shipping_cost: selected_shipping_option?.cost,
            // base_wrapping_cost: "0.0000",

            discount_amount: cart?.coupons[0]?.discounted_amount,
            payment_method: selectedPaymentMethod,
            payment_provider_id: data?.transactionId,
            status_id: 11,

            shipping_cost_ex_tax: selected_shipping_option?.cost,
            shipping_cost_inc_tax: selected_shipping_option?.cost,

            external_id: data?.transactionId,
            subtotal_ex_tax: subtotal_ex_tax,
            subtotal_inc_tax: subtotal_inc_tax,
            total_ex_tax: grand_total,
            total_inc_tax: grand_total,
          };
        } else {
          orderPayload = {
            customer_id: cart?.customer_id,
            customer_message: "",
            billing_address: {
              first_name: billing_address?.first_name,
              last_name: billing_address?.last_name,
              company: billing_address?.company,
              street_1: billing_address?.address1,
              street_2: billing_address?.address2,
              city: billing_address?.city,
              state: billing_address?.state,
              zip: billing_address?.postal_code,
              country: billing_address?.country,
              country_iso2: billing_address?.country_code,
              phone: billing_address?.phone,
              email,
            },
            default_currency_code: "USD",
            shipping_addresses: [
              {
                first_name: shipping_address?.first_name,
                last_name: shipping_address?.last_name,
                company: shipping_address?.company,
                street_1: shipping_address?.address1,
                street_2: shipping_address?.address2,
                city: shipping_address?.city,
                state: shipping_address?.state,
                zip: shipping_address?.postal_code,
                country: shipping_address?.country,
                country_iso2: shipping_address?.country_code,
                phone: shipping_address?.phone,
                email,
                shipping_method: selected_shipping_option?.description,
              },
            ],
            products: cart?.line_items?.physical_items?.map((item) => ({
              product_id: item?.product_id,
              name: item?.name,
              quantity: item?.quantity,
              price_inc_tax: item?.list_price,
              price_ex_tax: item?.list_price,
              sku: item?.sku,
              variant_id: item?.variant_id,
            })),
            // base_handling_cost: selected_shipping_option?.cost,
            // base_shipping_cost: selected_shipping_option?.cost,
            // base_wrapping_cost: "0.0000",

            discount_amount: cart?.coupons[0]?.discounted_amount,
            payment_method: selectedPaymentMethod,
            payment_provider_id: data?.transactionId,
            status_id: 11,

            shipping_cost_ex_tax: selected_shipping_option?.cost,
            shipping_cost_inc_tax: selected_shipping_option?.cost,

            external_id: data?.transactionId,
            subtotal_ex_tax: subtotal_ex_tax,
            subtotal_inc_tax: subtotal_inc_tax,
            total_ex_tax: grand_total,
            total_inc_tax: grand_total,
          };
        }

        // ✅ Call backend to complete BigCommerce order
        const res = await createPaypalOrder(orderPayload);
        if (res.success && selected_pickup_option) {
          const cartDetails = checkoutResult?.data?.cart;
          const shippingDetails = checkoutResult?.data?.consignments;
          const { grand_total } = checkoutResult?.data || "";
          const orderID = res?.data?.id;

          // const email = pickupLocation?.address?.email;
          // const customerEmail = cart?.email;

          const customerEmail = email;
          const storeEmail =
            pickupLocation?.store_email || pickupLocation?.address?.email; // fallback

          const billingAddress = checkoutResult?.data?.billing_address;

          console.log("customerEmail", customerEmail);
          console.log("storeEmail", storeEmail);
          console.log("billingAddress", billingAddress);

          await createEventForPickup(
            orderID,
            setLoading,
            cartDetails,
            grand_total,
            customerEmail,
            storeEmail,
            selectedPickupOption,
            billingAddress
          );

          setIsSuccessMessage("Payment successful! Redirecting...");

          // dispatch(resetCheckout());
          // dispatch(clearCart());
          // dispatch(clearEmail());

          // Optional redirect
          setTimeout(() => {
            window.location.href = `${
              import.meta.env.VITE_BC_STORE_URL
            }checkout/order-confirmation`;
          }, 1500);
        }
        // console.log(res);
        setIsSuccessMessage("Payment successful! Redirecting...");
        // Optional redirect
        // setTimeout(() => {
        //   window.location.href = `${
        //     import.meta.env.VITE_BC_STORE_URL
        //   }checkout/order-confirmation`;
        // }, 1500);
        // dispatch(resetCheckout());
        // dispatch(clearCart());
        // dispatch(clearEmail());
      } else {
        dispatch(setPaymentError("Payment failed"));
        console.error("Payment failed: " + data.error);
      }
    } catch (error) {
      const errorMessage =
        error?.details?.title ||
        error?.message ||
        "Error processing payment. please try again";
      dispatch(setPaymentError(errorMessage));
      console.error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full">
      {isSuccessMessage}
      {clientToken ? (
        <Button
          type="button"
          className="w-full py-3 px-4 uppercase text-xl mt-5"
          onClick={handlePayPalPayment}
          disabled={loading}
        >
          {loading ? "Processing..." : "Continue with PayPal"}
        </Button>
      ) : (
        <div className="w-full py-3 px-4 mt-5 bg-gray-200 animate-pulse rounded text-center text-xl uppercase">
          <LoadingSpin />
        </div>
      )}
    </div>
  );
};

export default BraintreePayPal;
