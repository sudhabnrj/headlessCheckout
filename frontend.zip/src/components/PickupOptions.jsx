import React from "react";

const PickupOptions = ({
  options,
  selectedPickupMethod,
  setSelectedPickupMethod,
}) => {
  return (
    <div>
      <h3 className="font-bold text-primary">Pickup Locations</h3>
      {options?.pickup_options?.length > 0 ? (
        options.pickup_options.map((pickup) => (
          <div
            key={pickup.id}
            className="border border-gray-300 p-5 bg-[#f5f5f5]"
          >
            <input
              type="radio"
              id={pickup.id}
              name="pickupMethod"
              checked={selectedPickupMethod === pickup.id}
              onChange={() => setSelectedPickupMethod(pickup.id)}
            />
            <label htmlFor={pickup.id}>{pickup.description}</label>
          </div>
        ))
      ) : (
        <p>No pickup locations available.</p>
      )}
    </div>
  );
};

export default PickupOptions;
