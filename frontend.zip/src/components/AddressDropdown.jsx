/* eslint-disable react/prop-types */
import React from "react";
import { GoTriangleDown } from "react-icons/go";

const AddressDropdown = ({
  isOpen,
  selectedAddress,
  customerDetails,
  onToggle,
  onSelectAddress,
  onOpenForm,
}) => {
  return (
    <div
      className={`dropdown flex flex-col w-full relative border border-gray-300 text-sm p-4 rounded-sm cursor-pointer hover:border-[#00abc9] z-10 ${
        isOpen ? "border-[#00abc9]" : ""
      }`}
    >
      <div className="flex flex-col w-full" onClick={onToggle}>
        {selectedAddress ? (
          <>
            <p>
              {selectedAddress.first_name} {selectedAddress.last_name}
            </p>
            <p>
              {selectedAddress.company} {selectedAddress.phone}
            </p>
            <p>
              {selectedAddress.street_1} / {selectedAddress.street_2}
            </p>
            <p>
              {selectedAddress.city}, {selectedAddress.state},{" "}
              {selectedAddress.zip} / {selectedAddress.country}
            </p>
          </>
        ) : (
          <p className="text-gray-400">Select an address</p>
        )}
      </div>

      <GoTriangleDown className="absolute top-1/2 right-4 -translate-y-1/2" />

      {isOpen && (
        <div className="dropdown-menu absolute top-full left-0 right-0 h-[200px] bg-white border border-gray-300 overflow-auto z-10">
          <div
            className="open-form py-2 px-4 font-medium border-b border-gray-300"
            onClick={onOpenForm}
          >
            Enter new address
          </div>
          <ul>
            {customerDetails.map((customer) => (
              <li
                key={customer.id}
                onClick={() => onSelectAddress(customer)}
                className="py-2 border-b border-gray-300 px-4 hover:bg-[#fcfcfc] hover:text-[#00abc9]"
              >
                <p>
                  {customer.first_name} {customer.last_name}
                </p>
                <p>
                  {customer.company} {customer.phone}
                </p>
                <p>
                  {customer.street_1} / {customer.street_2}
                </p>
                <p>
                  {customer.city}, {customer.state}, {customer.zip} /{" "}
                  {customer.country}
                </p>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default AddressDropdown;
