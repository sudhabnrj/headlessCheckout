import React from 'react'

const defaultAddress = () => {
  return (
    <>
      {defaultShippingAddress ? (
        <>
        <div
            className="vcard checkout-address--static border border-gray-300 p-3 cursor-pointer"
            onClick={handleDropdownOpen}
        >
            <p className="address-entry flex justify-start items-center gap-1 text-sm text-primary font-primary">
            <span>{defaultShippingAddress?.first_name} </span>
            <span>{defaultShippingAddress?.last_name}</span>
            </p>
            <p className="address-entry flex justify-start items-center gap-1 text-sm text-primary font-primary">
            <span>{defaultShippingAddress?.company}</span>
            <span>{defaultShippingAddress?.phone}</span>
            </p>
            <div className="adr">
            <p className="street-address address-entry text-sm text-primary font-primary">
                <span>{defaultShippingAddress?.address1} </span>
                <span>{defaultShippingAddress?.address2}</span>
            </p>
            <p className="address-entry text-sm text-primary font-primary">
                <span>{defaultShippingAddress?.city}, </span>
                <span>{defaultShippingAddress?.state}, </span>
                <span>{defaultShippingAddress?.zip} / </span>
                <span>{defaultShippingAddress?.country}</span>
            </p>
            </div>
        </div>

        {openDropdown && (
            <div className="dropdownMenu border border-t-0 border-gray-300 cursor-pointer">
            <ul className="flex flex-col">
                <li className="p-3 group">
                <Button className="text-primary text-sm font-primary font-medium w-full text-center">
                    Enter a new address
                </Button>
                </li>
                {customerDetails.map((address) => (
                <li
                    key={address.id}
                    className="dropdown-menu border-t border-gray-300 p-3"
                    onClick={() => handleAddressSelect(address)}
                >
                    <div>
                    <p className="address-entry flex justify-start items-center gap-1 text-sm text-primary font-primary">
                        <span>{address.first_name} </span>
                        <span>{address.last_name}</span>
                    </p>
                    <p className="address-entry flex justify-start items-center gap-1 text-sm text-primary font-primary">
                        <span>{address.company}</span>
                        <span>{address.phone}</span>
                    </p>
                    <div className="adr">
                        <p className="street-address address-entry text-sm text-primary font-primary">
                        <span>{address.address1} </span>
                        <span>{address.address2}</span>
                        </p>
                        <p className="address-entry text-sm text-primary font-primary">
                        <span>{address.city}, </span>
                        <span>{address.state}, </span>
                        <span>{address.zip} / </span>
                        <span>{address.country}</span>
                        </p>
                    </div>
                    </div>
                </li>
                ))}
            </ul>
            </div>
        )}
        </>
    ) : (
        
    )}
    </>
  )
}

export default defaultAddress
