/* eslint-disable react/prop-types */
import React from "react";
import PickupShimmer from "./ui/PickupShimmer";

const PickupInfoBox = ({ selectedPickupOption, loading }) => {
  if (!selectedPickupOption) return null;

  return (
    <>
      {loading ? (
        <PickupShimmer />
      ) : (
        <div className="text-sm bg-gray-300 text-slate-800 p-3 font-bold rounded-md flex flex-col gap-2 capitalize w-[calc(100%-100px)]">
          <div className="selected-pickup-info bg-gray-200 p-4 mt-4 flex flex-col gap-4">
            <h3 className="text-lg font-bold text-primary">
              Selected Pickup Method
            </h3>

            <p className="font-normal flex justify-between items-center">
              <span className="font-bold">Pickup Location:</span>
              {selectedPickupOption.display_name}
            </p>

            <p className="font-normal flex justify-between items-center">
              <span className="font-bold">Instructions:</span>
              {selectedPickupOption.collection_instructions}
            </p>

            <p className="flex justify-between items-center">
              <span>Estimated Collection Time:</span>
              {selectedPickupOption.collection_time_description}
            </p>
          </div>
        </div>
      )}
    </>
  );
};

export default PickupInfoBox;
