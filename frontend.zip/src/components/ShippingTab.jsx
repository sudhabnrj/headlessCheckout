/* eslint-disable react/prop-types */
import Title from "./ui/Title";
import Button from "./ui/Button";
import { useEffect, useState } from "react";
import useCustomerAddresses from "../hooks/useCustomerAddresses";
import ShippingMethodForm from "./ShippingMethodForm";
import { useSelector } from "react-redux";
import useCheckout from "../hooks/useCheckout";
import AlertError from "./ui/AlertError";

const ShippingTab = () => {
  const checkoutResult =
    useSelector((store) => store.checkout.checkoutData) || {};
  const customerDetails = useSelector((state) => state.customer.customer) || [];
  const loading = useSelector((state) => state.loader.loading);
  const error = useSelector((state) => state.error.error);
  const [openDropdown, setOpenDropdown] = useState(false);

  // Get customer ID
  const customerID = checkoutResult?.data?.cart?.customer_id || null;
  // console.log("Extracted customerID:", customerID);

  // Fetch checkout data and customer addresses
  // useCheckout("abb02a7b-d8dd-4254-a158-66e4f12e91e5");
  useCustomerAddresses(customerID);

  // console.log("customerDetails", customerDetails);
  // console.log("checkoutResult page", checkoutResult?.data);

  // Extract default shipping address
  const defaultShippingAddress =
    checkoutResult?.data?.cart?.consignments?.[0]?.shipping_address || null;
  // console.log("defaultShippingAddress", defaultShippingAddress);

  // State for selected address
  const [selectedAddress, setSelectedAddress] = useState(
    defaultShippingAddress
  );

  useEffect(() => {
    if (customerDetails?.length > 0 && !selectedAddress?.id) {
      setSelectedAddress(customerDetails[0]); // Set first address as default if none is selected
    }
  }, [customerDetails, selectedAddress]);

  const handleDropdownOpen = () => {
    setOpenDropdown((prev) => !prev);
  };

  const handleAddressSelect = (address) => {
    setSelectedAddress(address);
    setOpenDropdown(false);
  };

  if (error) {
    return <AlertError message={error} />;
  }

  if (loading) {
    return "Loading...";
  }

  console.log("Full Checkout Data:", checkoutResult);

  return (
    <div className="w-full border-b border-gray-200">
      <Title title="Shipping" />
      <div className="shipping-header mt-5 mb-3">
        <h3 className="font-semibold font-primary text-primary text-base mb-5">
          Shipping Address
        </h3>
      </div>
      {customerID ? (
        <>
          {/* Selected Address Display */}
          <div
            className="vcard checkout-address--static border border-gray-300 p-3 cursor-pointer"
            onClick={handleDropdownOpen}
          >
            <p className="address-entry flex justify-start items-center gap-1 text-sm text-primary font-primary">
              <span className="first-name">{selectedAddress?.first_name} </span>
              <span className="family-name">{selectedAddress?.last_name}</span>
            </p>
            <p className="address-entry flex justify-start items-center gap-1 text-sm text-primary font-primary">
              <span className="company-name">{selectedAddress?.company}</span>
              <span className="tel">{selectedAddress?.phone}</span>
            </p>
            <div className="adr">
              <p className="street-address address-entry text-sm text-primary font-primary">
                <span className="address-line-1">
                  {selectedAddress?.street_1}{" "}
                </span>
                <span className="address-line-2">
                  {selectedAddress?.street_2}
                </span>
              </p>
              <p className="address-entry text-sm text-primary font-primary">
                <span className="locality">{selectedAddress?.city}, </span>
                <span className="region">{selectedAddress?.state}, </span>
                <span className="postal-code">{selectedAddress?.zip} / </span>
                <span className="country-name">{selectedAddress?.country}</span>
              </p>
            </div>
          </div>

          {/* Dropdown Menu */}
          {openDropdown && (
            <div className="dropdownMenu border border-t-0 border-gray-300 cursor-pointer">
              <ul className="flex flex-col">
                <li className="p-3 group">
                  <Button
                    type="button"
                    className="text-primary hover:text-white/60 text-sm font-primary font-medium w-full text-center"
                  >
                    Enter a new address
                  </Button>
                </li>
                {/* List all customer addresses */}
                {customerDetails.map((address) => (
                  <li
                    key={address?.id}
                    className="dropdown-menu border-t border-gray-300 p-3"
                    onClick={() => handleAddressSelect(address)}
                  >
                    <div>
                      <p className="address-entry flex justify-start items-center gap-1 text-sm text-primary font-primary">
                        <span className="first-name">
                          {address?.first_name}{" "}
                        </span>
                        <span className="family-name">
                          {address?.last_name}
                        </span>
                      </p>
                      <p className="address-entry flex justify-start items-center gap-1 text-sm text-primary font-primary">
                        <span className="company-name">{address?.company}</span>
                        <span className="tel">{address?.phone}</span>
                      </p>
                      <div className="adr">
                        <p className="street-address address-entry text-sm text-primary font-primary">
                          <span className="address-line-1">
                            {address?.street_1}{" "}
                          </span>
                          <span className="address-line-2">
                            {address?.street_2}
                          </span>
                        </p>
                        <p className="address-entry text-sm text-primary font-primary">
                          <span className="locality">{address?.city}, </span>
                          <span className="region">{address?.state}, </span>
                          <span className="postal-code">{address?.zip} / </span>
                          <span className="country-name">
                            {address?.country}
                          </span>
                        </p>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </>
      ) : (
        <ShippingMethodForm />
      )}
    </div>
  );
};

export default ShippingTab;
