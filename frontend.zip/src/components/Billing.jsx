import Title from "./ui/Title";
import Button from "./ui/Button";
import Label from "./ui/Label";
import { Link } from "react-router";
import Input from "./ui/Input";
import Checkbox from "./ui/Checkbox";

const Billing = () => {
  return (
    <div className="w-full border-b border-gray-200">
      <Title title={"Billing"} />
      <form className="mt-8">
        <h3 className="font-semibold font-primary text-primary text-base mb-5">
          Billing Address
        </h3>
        <div className="w-full flex flex-col gap-4">
          <div className="w-full flex justify-between items-center gap-4">
            <div className="flex flex-col w-1/2">
              <Label label={"First Name"} />
              <Input type="text" name="firstName" />
            </div>
            <div className="flex flex-col w-1/2">
              <Label label={"Last Name"} />
              <Input type="text" name="lastName" />
            </div>
          </div>
          <div className="w-full flex justify-between items-center gap-4">
            <div className="flex flex-col w-full">
              <Label label={"Company Name (Optional)"} />
              <Input type="text" name="companyName" />
            </div>
          </div>
          <div className="w-full flex justify-between items-center gap-4">
            <div className="flex flex-col w-full">
              <Label label={"Phone Number"} />
              <Input type="text" name="phoneNumber" />
            </div>
          </div>
          <div className="w-full flex justify-between items-center gap-4">
            <div className="flex flex-col w-full">
              <Label label={"Address"} />
              <Input type="text" name="address" />
            </div>
          </div>
          <div className="w-full flex justify-between items-center gap-4">
            <div className="flex flex-col w-full">
              <Label label={"Apartment/Suite/Building (Optional)"} />
              <Input type="text" name="appartment" />
            </div>
          </div>
          <div className="w-full flex justify-between items-center gap-4">
            <div className="flex flex-col w-full">
              <Label label={"City"} />
              <Input type="text" name="city" />
            </div>
          </div>
          <div className="w-full flex justify-between items-center gap-4">
            <div className="flex flex-col w-full">
              <Label label={"Country"} />
              <select
                name="country"
                className="border border-gray-200 text-sm h-11 px-4 py-2 w-full outline-none rounded-md focus:border-primary"
              >
                <option value="">Select a country</option>
                <option value="AF">Afghanistan</option>
              </select>
            </div>
          </div>
          <div className="w-full flex justify-between items-center gap-4">
            <div className="flex flex-col w-[60%]">
              <Label label={"State/Province (Optional)"} />
              <Input type="text" name="state" />
            </div>
            <div className="flex flex-col w-[40%]">
              <Label label={"Postal Code"} />
              <Input type="text" name="postalCode" />
            </div>
          </div>
          <div className="w-full flex justify-between items-center gap-4">
            <div className="flex flex-col w-full">
              <Checkbox
                id="terms-agree"
                label="I agree to the terms and conditions."
              />
            </div>
          </div>
          <div className="w-full mt-5 mb-8">
            <Button className={"min-w-[231px] py-3 px-4"}>Continue</Button>
          </div>
        </div>
      </form>
    </div>
  );
};

export default Billing;
