/* eslint-disable react/prop-types */
import React from "react";
import { useSelector } from "react-redux";
import Title from "../components/ui/Title";
import EmailForm from "./EmailForm";
import Button from "../components/ui/Button"; // adjust path as per your project
import LoadingSpin from "./ui/LoadingSpin";
import PasswordFields from "./ui/PasswordFields";
import bigcommerceLogoutAuth from "./auth/bigcommerceLogoutAuth";
import { fetchUpdatedCheckout } from "../lib/fetchUpdatedCheckout";

const CustomerTab = ({
  customerID,
  email,
  custEmail,
  password,
  customerError,
  isEmailEditing,
  handleEditEmail,
  handleEmailChange,
  handleEmailSubmit,
  loading,
  isSigningIn,
  setIsSigningIn,
  onClick,
  handlePasswordChange,
}) => {
  // const handleLogout = async (e) => {
  //   e.preventDefault();

  //   try {
  //     const res = await bigcommerceLogoutAuth(dispatch);

  //     if (!res?.data?.logout?.result) {
  //       throw new Error("Logout failed");
  //     }

  //     // ✅ Force-clear BigCommerce cookies from browser
  //     document.cookie = "SHOP_TOKEN=; Max-Age=0; path=/";
  //     document.cookie = "SHOP_SESSION_TOKEN=; Max-Age=0; path=/";
  //     document.cookie = "SHOP_SESSION_ROTATION_TOKEN=; Max-Age=0; path=/";

  //     // ✅ Re-fetch guest checkout state
  //     const updatedCheckoutRes = await fetchUpdatedCheckout(
  //       dispatch,
  //       checkoutID
  //     );

  //     console.log("updated Checkout Data", updatedCheckoutRes);
  //   } catch (err) {
  //     console.error("Logout error:", err.message);
  //   }
  // };

  return (
    <div className="w-full border-b border-gray-200 pb-5">
      <Title title="Customer" />

      {!isEmailEditing && email ? (
        <div className="flex w-full items-center justify-between py-5">
          <div className="flex justify-start items-center">
            <span className="font-primary text-primary font-medium text-sm">
              {email}
            </span>
          </div>
          {!customerID && (
            <Button
              onClick={handleEditEmail}
              className="!text-primary bg-transparent border border-primary"
            >
              Edit
            </Button>
          )}
          {/* <Button
            onClick={handleLogout}
            className="!text-primary bg-transparent border border-primary"
          >
            Logout
          </Button> */}
        </div>
      ) : (
        <>
          <div
            className={`mt-8 flex justify-between ${
              isSigningIn ? "flex-col" : "flex-row"
            } items-end gap-4 relative`}
          >
            <EmailForm
              custEmail={custEmail}
              handleEmailChange={handleEmailChange}
            />
            {isSigningIn && (
              <PasswordFields
                password={password}
                handlePasswordChange={handlePasswordChange}
              />
            )}
            {isSigningIn ? (
              <div className="flex justify-items-start items-start mr-auto gap-4">
                <Button
                  type="button"
                  className="min-w-[231px] min-h-[44px]"
                  disabled={loading}
                  onClick={onClick}
                >
                  {loading ? <LoadingSpin /> : "Sign In"}
                </Button>
                <Button
                  type="button"
                  className="min-h-[44px] !text-primary bg-transparent border border-primary rounded-sm py-2 px-4 uppercase font-primary font-medium text-sm  cursor-pointer"
                  onClick={() => setIsSigningIn(false)}
                >
                  Cancel
                </Button>
              </div>
            ) : (
              <Button
                type="button"
                className="min-w-[231px] min-h-[44px]"
                onClick={handleEmailSubmit}
                disabled={loading}
              >
                {loading ? <LoadingSpin /> : "Continue"}
              </Button>
            )}
          </div>
          {!isSigningIn && (
            <p className="text-sm mt-5">
              Already have an account?{" "}
              <span
                data-test="customer-continue-button"
                role="button"
                tabIndex="0"
                className="cursor-pointer text-blue"
                onClick={() => setIsSigningIn(true)}
              >
                Sign in now
              </span>
            </p>
          )}
          {customerError && (
            <p className="text-red-500 mt-2">{customerError}</p>
          )}
        </>
      )}
    </div>
  );
};

export default CustomerTab;
