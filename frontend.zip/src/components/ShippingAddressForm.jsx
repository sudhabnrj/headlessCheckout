import React from "react";
import Label from "./ui/Label";
import Input from "./ui/Input";

const ShippingAddressForm = ({ formData, handleChange }) => {
  return (
    <div className="w-full flex flex-col gap-4">
      <div className="w-full flex justify-between items-center gap-4">
        <div className="flex flex-col w-1/2">
          <Label label="First Name" />
          <Input
            type="text"
            name="firstName"
            value={formData.firstName}
            onChange={handleChange}
          />
        </div>
        <div className="flex flex-col w-1/2">
          <Label label="Last Name" />
          <Input
            type="text"
            name="lastName"
            value={formData.lastName}
            onChange={handleChange}
          />
        </div>
      </div>

      <div className="flex flex-col">
        <Label label="Company Name (Optional)" />
        <Input
          type="text"
          name="companyName"
          value={formData.companyName}
          onChange={handleChange}
        />
      </div>

      <div className="flex flex-col">
        <Label label="Phone Number" />
        <Input
          type="text"
          name="phoneNumber"
          value={formData.phoneNumber}
          onChange={handleChange}
        />
      </div>

      <div className="flex flex-col">
        <Label label="Address" />
        <Input
          type="text"
          name="address"
          value={formData.address}
          onChange={handleChange}
        />
      </div>

      <div className="flex flex-col">
        <Label label="Apartment/Suite/Building (Optional)" />
        <Input
          type="text"
          name="apartment"
          value={formData.apartment}
          onChange={handleChange}
        />
      </div>

      <div className="flex flex-col">
        <Label label="City" />
        <Input
          type="text"
          name="city"
          value={formData.city}
          onChange={handleChange}
        />
      </div>

      <div className="flex flex-col">
        <Label label="Country" />
        <select
          name="country"
          value={formData.country}
          onChange={handleChange}
          className="border border-gray-200 text-sm h-11 px-4 py-2 w-full outline-none rounded-md focus:border-primary"
        >
          <option value="">Select a country</option>
          <option value="US">United States</option>
          <option value="CA">Canada</option>
          <option value="IN">India</option>
        </select>
      </div>

      <div className="w-full flex justify-between items-center gap-4">
        <div className="flex flex-col w-[60%]">
          <Label label="State/Province (Optional)" />
          <Input
            type="text"
            name="state"
            value={formData.state}
            onChange={handleChange}
          />
        </div>
        <div className="flex flex-col w-[40%]">
          <Label label="Postal Code" />
          <Input
            type="text"
            name="postalCode"
            value={formData.postalCode}
            onChange={handleChange}
          />
        </div>
      </div>
    </div>
  );
};

export default ShippingAddressForm;
