import React from "react";
import Mastercard from "../../assets/mastercard.svg";

const MasterCardIcon = () => {
  return <img className="w-10" src={Mastercard} alt="Mastercard" />;
};

export default MasterCardIcon;
