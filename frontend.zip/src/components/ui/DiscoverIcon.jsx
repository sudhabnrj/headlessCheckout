import React from "react";
import Discover from "../../assets/discover.svg";

const DiscoverIcon = () => {
  return <img className="w-14" src={Discover} alt="Discover" />;
};

export default DiscoverIcon;
