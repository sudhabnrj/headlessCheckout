import LOADER from "../../assets/loader.gif";

const Loader = () => {
  return (
    <div className="loader absolute top-0 left-0 right-0 bottom-0 z-10 w-full h-full flex justify-center items-center bg-white/80">
      <div className="">
        <img src={LOADER} alt="Loader" />
      </div>
    </div>
  );
};

export default Loader;
