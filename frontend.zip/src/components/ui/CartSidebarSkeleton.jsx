import React from "react";

const CartSidebarSkeleton = () => {
  return (
    <div className="cart-list flex flex-col w-full border rounded-sm border-gray-200 shadow animate-pulse">
      {/* Header */}
      <div className="card-header w-full flex justify-between items-center p-5 rounded-none border-b border-gray-200">
        <div className="h-6 w-32 bg-gray-300 rounded"></div>
        <div className="h-4 w-20 bg-gray-300 rounded"></div>
      </div>

      {/* Cart Items */}
      <div className="card-body w-full flex flex-col p-5">
        <div className="h-4 w-24 bg-gray-300 rounded mb-4"></div>
        {[...Array(2)].map((_, index) => (
          <div key={index} className="cart-item flex w-full gap-4 mb-4">
            <div className="w-[25%] h-16 bg-gray-300 rounded"></div>
            <div className="w-1/2 flex flex-col gap-2">
              <div className="h-4 w-32 bg-gray-300 rounded"></div>
              <div className="h-3 w-20 bg-gray-300 rounded"></div>
            </div>
            <div className="w-[25%] flex justify-end">
              <div className="h-4 w-10 bg-gray-300 rounded"></div>
            </div>
          </div>
        ))}
      </div>

      {/* Subtotal Section */}
      <div className="cart-subtotal flex flex-col gap-3 border-t border-gray-200 p-5">
        {[...Array(3)].map((_, index) => (
          <div
            key={index}
            className="cart-priceItem flex justify-between items-center"
          >
            <div className="h-4 w-20 bg-gray-300 rounded"></div>
            <div className="h-4 w-10 bg-gray-300 rounded"></div>
          </div>
        ))}
        <div className="h-4 w-36 bg-gray-300 rounded"></div>
      </div>

      {/* Total */}
      <div className="cart-total flex justify-between items-center border-t border-gray-200 p-5">
        <div className="h-5 w-24 bg-gray-300 rounded"></div>
        <div className="h-9 w-[125px] bg-gray-300 rounded"></div>
      </div>
    </div>
  );
};

export default CartSidebarSkeleton;
