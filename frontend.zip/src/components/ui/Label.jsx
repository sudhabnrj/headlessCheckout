import React from "react";

const Label = ({ label, className }) => {
  return (
    <label
      className={`${className} text-[14px] text-[#666] font-medium font-primary w-full mb-2 block`}
    >
      {label}
    </label>
  );
};

export default Label;
