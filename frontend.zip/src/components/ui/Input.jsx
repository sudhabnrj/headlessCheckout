/* eslint-disable react/prop-types */
import React from "react";

const Input = ({ className = "", ...props }) => {
  return (
    <input
      className={`${className} border border-gray-200 text-sm h-11 px-4 py-2 w-full outline-none rounded-md focus:border-primary`}
      {...props}
    />
  );
};

export default Input;
