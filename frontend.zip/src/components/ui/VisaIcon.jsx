import React from "react";
import VISA from "../../assets/visa.svg";
const VisaIcon = () => {
  return <img className="w-14" src={VISA} alt="visa" />;
};

export default VisaIcon;
