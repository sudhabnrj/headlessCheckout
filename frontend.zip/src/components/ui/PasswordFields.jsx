/* eslint-disable react/prop-types */
import React from "react";
import Input from "./Input";
import Label from "./Label";

const PasswordFields = ({ password, handlePasswordChange }) => {
  return (
    <div className="w-full ">
      <Label label={"Password"} />
      <div className="flex gap-4">
        <Input
          type="password"
          name="password"
          placeholder="Password"
          value={password || ""}
          onChange={handlePasswordChange}
        />
      </div>
    </div>
  );
};

export default PasswordFields;
