import React from "react";

const AlertError = ({ message }) => {
  return (
    <div
      className="alert bg-[#f8d7da] text-[#58151c] border-[#f1aeb5] my-3"
      role="alert"
    >
      {message}
    </div>
  );
};

export default AlertError;
