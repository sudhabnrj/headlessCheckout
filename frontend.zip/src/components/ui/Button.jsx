import React from "react";

const Button = ({ children, disabled, className, ...props }) => {
  return (
    <button
      {...props}
      disabled={disabled}
      className={`${className} bg-primary text-white rounded-sm py-2 px-4 uppercase font-primary font-medium text-sm  ${
        disabled ? "opacity-50 cursor-not-allowed" : "cursor-pointer"
      }`}
    >
      {children}
    </button>
  );
};

export default Button;
