import React from "react";
import Americanexpress from "../../assets/american-express.png";
const AmericanExpressIcon = () => {
  return <img className="w-9" src={Americanexpress} alt="Discover" />;
};

export default AmericanExpressIcon;
