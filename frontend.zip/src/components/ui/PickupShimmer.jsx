const PickupShimmer = () => {
  return (
    <div className="animate-pulse text-sm bg-gray-300 text-slate-800 p-3 font-bold rounded-md flex flex-col gap-2 capitalize w-[calc(100%-100px)] min-h-[208px]">
      <div className="selected-pickup-info bg-gray-200 p-4 mt-4 flex flex-col gap-4 w-full">
        <div className="h-5 w-1/2 bg-gray-300 rounded"></div>

        <div className="flex justify-between items-center">
          <span className="h-4 w-1/3 bg-gray-300 rounded"></span>
          <span className="h-4 w-1/2 bg-gray-300 rounded"></span>
        </div>

        <div className="flex justify-between items-center">
          <span className="h-4 w-1/3 bg-gray-300 rounded"></span>
          <span className="h-4 w-1/2 bg-gray-300 rounded"></span>
        </div>

        <div className="flex justify-between items-center">
          <span className="h-4 w-1/2 bg-gray-300 rounded"></span>
          <span className="h-4 w-1/3 bg-gray-300 rounded"></span>
        </div>
      </div>
    </div>
  );
};

export default PickupShimmer;
