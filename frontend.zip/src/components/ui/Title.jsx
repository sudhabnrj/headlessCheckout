import React from "react";

const Title = ({ className, title }) => {
  return (
    <h2
      className={`${className} text-black font-primary text-2xl font-semibold`}
    >
      {title}
    </h2>
  );
};

export default Title;
