/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from "react";
import { API_URL } from "../lib/constant";
import Label from "./ui/Label";
import Input from "./ui/Input";
import Checkbox from "./ui/Checkbox";
import Button from "./ui/Button";
import RadioButton from "./ui/RadioButton";
import { useDispatch, useSelector } from "react-redux";
import { addCheckoutData } from "../redux/checkoutSlice";
import ShippingOptions from "./ShippingOptions";
import ShippingAddressForm from "./ShippingAddressForm";

const ShippingMethodForm = () => {
  const checkoutResult =
    useSelector((store) => store.checkout.checkoutData) || {};
  // const cartItems = useSelector((store) => store.cart.items) || {};
  const [response, setResponse] = useState(null);
  const [pickupOption, setPickupOption] = useState("");
  const [loading, setLoading] = useState(false);
  const [isError, setIsError] = useState(null);
  const [selectedShippingMethod, setSelectedShippingMethod] = useState(null);
  const [selectedPickupMethod, setSelectedPickupMethod] = useState(null);
  const [geoLocation, setGeoLocation] = useState(null);
  const dispatch = useDispatch();

  const checkoutID = checkoutResult?.data?.id;

  const cartItems =
    checkoutResult?.data?.cart?.line_items?.physical_items || [];

  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    companyName: "",
    phoneNumber: "",
    address: "",
    apartment: "",
    city: "",
    country: "",
    state: "",
    postalCode: "",
  });

  //Fetch geolocation
  useEffect(() => {
    const { address, city, state, postalCode, country } = formData;
    if (address && city && country && postalCode) {
      fetchGeoCode(address, city, state, postalCode, country);
    }
  }, [
    formData.address,
    formData.city,
    formData.state,
    formData.postalCode,
    formData.country,
  ]);

  // Fetch shipping methods when geoLocation is available
  useEffect(() => {
    if (geoLocation) {
      submitShippingMethod();
    }
  }, [geoLocation]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const { available_shipping_options } = response?.data?.consignments[0] || {};

  const fetchGeoCode = async (address, city, state, postal_code, country) => {
    const formattedAddress = `${address},${city},${state},${postal_code},${country}`;
    const API_KEY = import.meta.env.VITE_GEOCODE_API_KEY_NEW;
    try {
      const res = await fetch(
        `https://api.geoapify.com/v1/geocode/search?text=${formattedAddress}&apiKey=${API_KEY}`
        // `https://geocode.maps.co/search?q=${formattedAddress}&api_key=${API_KEY}`
      );
      if (!res.ok) {
        console.warn("GeoCoding failed, proceeding without coordinates.");
        return null;
      }
      const data = await res.json();

      if (!data.features || data.features.length === 0) {
        console.warn("No coordinates found, proceeding without coordinates.");
        return null;
      }
      const geoLocation = {
        latitude: data.features[0]?.properties?.lat,
        longitude: data.features[0]?.properties?.lon,
      };

      setGeoLocation(geoLocation);
      console.log("GEO Code", {
        latitude: data.features[0]?.properties?.lat,
        longitude: data.features[0]?.properties?.lon,
      });
      return geoLocation;
    } catch (error) {
      console.error("Geolocation error:", error);
      return null;
    }
  };

  //Submit Shipping Address
  const submitShippingMethod = async (e) => {
    e.preventDefault();
    setLoading(true);
    setIsError(null);

    const {
      firstName,
      lastName,
      address,
      city,
      country,
      state,
      postalCode,
      phoneNumber,
      companyName,
      apartment,
    } = formData;

    if (
      !firstName ||
      !lastName ||
      !address ||
      !city ||
      !country ||
      !postalCode
    ) {
      setIsError("Please fill in all required fields.");
      setLoading(false);
      return;
    }

    try {
      //Fetch Geolocation
      const geoLocation = await fetchGeoCode(
        address,
        city,
        state,
        postalCode,
        country
      );

      console.log("shipping geoLocation", geoLocation);

      // Construct payload dynamically
      const payload = [
        {
          address: {
            email: "sucho@example.com",
            country_code: country,
            first_name: firstName,
            last_name: lastName,
            address1: address,
            city: city,
            state_or_province: state,
            state_or_province_code: state,
            postal_code: postalCode,
            phone: phoneNumber,
            custom_fields: [
              {
                field_id: "field_25",
                field_value: "Great!",
              },
            ],
          },
          line_items: cartItems.map((item) => ({
            item_id: item.id,
            quantity: item.quantity,
          })),
          coordinates: geoLocation,
        },
        {
          address: {
            email: "sucho@example.com",
            country_code: country,
            first_name: firstName,
            last_name: lastName,
            company: companyName,
            address1: address,
            address2: apartment,
            city: city,
            state_or_province: state,
            state_or_province_code: state,
            postal_code: postalCode,
            phone: phoneNumber,
            custom_fields: [
              {
                field_id: "field_25",
                field_value: "You're Welcome",
              },
            ],
          },
          line_items: cartItems.map((item) => ({
            item_id: item.id,
            quantity: item.quantity,
          })),
          coordinates: geoLocation,
        },
      ];

      const res = await fetch(
        `${API_URL}/checkouts/${checkoutID}/consignments?include=consignments.available_shipping_options`,
        {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            "X-Auth-Token": import.meta.env.VITE_APP_ACCESS_TOKEN,
          },
          body: JSON.stringify(payload),
          cache: "no-cache",
        }
      );

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.title || "Failed to submit shipping method");
      }

      const data = await res.json();
      // console.log("API Response:", data);
      setResponse(data);
      await fetchPickupOptions(geoLocation);

      console.log("Shipping Form Response:", data?.data);
    } catch (error) {
      console.error("Submission Error:", error);
      setIsError(error.message);
    } finally {
      setLoading(false);
    }
  };

  //Fetch Pickup Options
  const fetchPickupOptions = async (geoLocation) => {
    if (!geoLocation) {
      // console.warn("Missing geolocation data.");
      return null;
    }

    setLoading(true);
    setIsError(null);
    // Ensure cartItems is an array
    const safeCartItems = Array.isArray(cartItems) ? cartItems : [];
    const pickupPayload = {
      search_area: {
        coordinates: {
          latitude: Number(geoLocation.latitude),
          longitude: Number(geoLocation.longitude),
        },
        radius: {
          value: 20,
          unit: "KM",
        },
      },
      items: safeCartItems.map((item) => ({
        variant_id: item.variant_id,
        quantity: item.quantity,
      })),
    };

    try {
      const res = await fetch(`${API_URL}/pickup-options`, {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          "X-Auth-Token": import.meta.env.VITE_APP_ACCESS_TOKEN,
        },
        body: JSON.stringify(pickupPayload),
      });

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.title || "Failed to fetch Pickup Options.");
      }
      const data = await res.json();
      setPickupOption(data.results[0]);
      console.log("Available pickup Method", data.results[0]);
    } catch (error) {
      console.error(error);
      setIsError(error);
    } finally {
      setLoading(false);
    }
  };

  const handleShippingSelection = async (id) => {
    setSelectedShippingMethod(id);
    setSelectedPickupMethod(null); // Clear pickup method when selecting shipping

    // Fetch latest checkout data to get a valid consignment ID
    const updatedCheckoutRes = await fetch(
      `${API_URL}/checkouts/${checkoutID}`,
      {
        method: "GET",
        headers: {
          Accept: "application/json",
          "X-Auth-Token": import.meta.env.VITE_APP_ACCESS_TOKEN,
        },
      }
    );

    if (!updatedCheckoutRes.ok) {
      console.error("Failed to fetch updated checkout data");
      return;
    }

    const updatedCheckoutData = await updatedCheckoutRes.json();
    const latestConsignment = updatedCheckoutData?.data?.consignments[0];

    if (!latestConsignment) {
      console.error("No valid consignment found");
      return;
    }

    const consignmentId = latestConsignment.id;

    try {
      const res = await fetch(
        `${API_URL}/checkouts/${checkoutID}/consignments/${consignmentId}`,
        {
          method: "PUT",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            "X-Auth-Token": import.meta.env.VITE_APP_ACCESS_TOKEN,
          },
          body: JSON.stringify({
            shipping_option_id: id,
          }),
        }
      );

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.title || "Failed to update shipping method");
      }

      const newCheckoutData = await res.json();
      dispatch(
        addCheckoutData({
          ...checkoutResult,
          data: {
            ...checkoutResult.data,
            consignments: newCheckoutData.data.consignments,
            shipping_cost_total_inc_tax:
              newCheckoutData.data.shipping_cost_total_inc_tax,
            grand_total: newCheckoutData.data.grand_total,
            tax_total: newCheckoutData.data.tax_total,
          },
        })
      );
    } catch (error) {
      console.error("Error updating shipping method:", error);
    }
  };

  const handlePickupSelection = async (id) => {
    setSelectedPickupMethod(id);
    setSelectedShippingMethod(null); // Clear shipping method when selecting pickup

    if (!checkoutID) {
      console.error("Checkout ID is missing");
      return;
    }

    try {
      // Submit shipping address again to ensure a consignment exists
      await submitShippingMethod(event);

      const updatedCheckoutRes = await fetch(
        `${API_URL}/checkouts/${checkoutID}`,
        {
          method: "GET",
          headers: {
            Accept: "application/json",
            "X-Auth-Token": import.meta.env.VITE_APP_ACCESS_TOKEN,
          },
        }
      );

      if (!updatedCheckoutRes.ok) {
        console.error("Failed to fetch updated checkout data");
        return;
      }

      const updatedCheckoutData = await updatedCheckoutRes.json();
      const latestConsignment = updatedCheckoutData?.data?.consignments[0];

      if (!latestConsignment) {
        console.error("No valid consignment found");
        return;
      }

      const consignmentId = latestConsignment.id;

      const res = await fetch(
        `${API_URL}/checkouts/${checkoutID}/consignments/${consignmentId}`,
        {
          method: "PUT",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            "X-Auth-Token": import.meta.env.VITE_APP_ACCESS_TOKEN,
          },
          body: JSON.stringify({
            pickup_option: {
              pickup_method_id: id,
            },
          }),
        }
      );

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.title || "Failed to update pickup method");
      }

      const newCheckoutData = await res.json();
      dispatch(
        addCheckoutData({
          ...checkoutResult,
          data: {
            ...checkoutResult.data,
            consignments: newCheckoutData.data.consignments,
            pickup_method: newCheckoutData.data.pickup_method,
            grand_total: newCheckoutData.data.grand_total,
            tax_total: newCheckoutData.data.tax_total,
          },
        })
      );

      console.log(newCheckoutData);
    } catch (error) {
      console.error("Error updating pickup method:", error);
    }
  };

  return (
    <form className="mt-8">
      <div className="w-full flex flex-col gap-4">
        <ShippingAddressForm formData={formData} handleChange={handleChange} />

        <>
          <h3 className="font-bold font-primary text-primary text-base mb-0 mt-5">
            Shipping Method
          </h3>
          {available_shipping_options?.length > 0 ? (
            available_shipping_options.map((shipping) => (
              <ShippingOptions
                key={shipping?.id}
                id={shipping?.id}
                label={shipping?.description}
                checked={selectedShippingMethod === shipping.id}
                onChange={() => handleShippingSelection(shipping.id)}
                shippingCost={`₹${shipping?.cost.toFixed(2)}`}
              />
            ))
          ) : (
            <div className="checkout-shipping-options border border-gray-300 p-10 w-full bg-[#f5f5f5]">
              Please enter a shipping address in order to see shipping quotes
            </div>
          )}
        </>
        {pickupOption === null ? (
          // While fetching, show nothing or a loader
          <p>Loading pickup options...</p>
        ) : pickupOption?.pickup_options?.length > 0 ? (
          <>
            <h3 className="font-bold font-primary text-primary text-base mb-0 mt-5">
              Pickup Location
            </h3>
            {pickupOption?.pickup_options.map((picLocation, index) => (
              <div
                key={index}
                className="checkout-shipping-options border border-gray-300 p-5 w-full bg-[#f5f5f5]"
              >
                <div className="flex justify-between items-center">
                  <div className="flex justify-start items-center flex-col gap-4">
                    <RadioButton
                      name="customMethod"
                      id={picLocation?.pickup_method?.id}
                      label={picLocation?.pickup_method?.display_name}
                      description={
                        picLocation?.pickup_method?.collection_instructions
                      }
                      checked={
                        selectedPickupMethod === picLocation?.pickup_method?.id
                      }
                      onChange={() =>
                        handlePickupSelection(picLocation?.pickup_method?.id)
                      }
                    />
                  </div>
                  <div className="shippingCost justify-end items-center">
                    <span className="shippingOption-price text-primary font-bold font-primary">
                      {picLocation?.pickup_method?.collection_time_description}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </>
        ) : pickupOption ? (
          // Show this only after data is confirmed empty
          <div className="checkout-shipping-options border border-gray-300 p-5 w-full bg-[#f5f5f5]">
            <p>Pickup option is not available at your location.</p>
          </div>
        ) : null}
        <div className="w-full mt-5 mb-8">
          <Button
            onClick={submitShippingMethod}
            type="button"
            className="min-w-[231px] py-3 px-4"
            disabled={loading}
          >
            {loading ? "Loading..." : "Continue"}
          </Button>
        </div>
      </div>
      {isError && <p className="text-red-500">{isError}</p>}
      {response && (
        <p className="text-green-500">
          Shipping method submitted successfully!
        </p>
      )}
    </form>
  );
};

export default ShippingMethodForm;
