import RadioButton from "./ui/RadioButton";
import Title from "./ui/Title";
import VisaIcon from "./ui/VisaIcon";
import MasterCardIcon from "./ui/MasterCardIcon";
import DiscoverIcon from "./ui/DiscoverIcon";
import AmericanExpressIcon from "./ui/AmericanExpressIcon";
import Label from "./ui/Label";
import Input from "./ui/Input";
import { TiLockClosed } from "react-icons/ti";
import Button from "./ui/Button";

const PaymentTab = () => {
  return (
    <div className="w-full border-b border-gray-200">
      <Title title={"Payment"} />
      <div className="mt-8">
        <div className="accordian border border-gray-300 w-full">
          <div className="accordian-tab bg-gray-100">
            <div className="accordian-header w-full flex justify-between items-center px-4">
              <RadioButton
                name="paymentCard"
                id="creditCard"
                label={"Credit Card"}
              />
              <div className="flex justify-end items-center ">
                <VisaIcon />
                <MasterCardIcon />
                <DiscoverIcon />
                <AmericanExpressIcon />
              </div>
            </div>
            <div className="accordian-body border-b border-gray-300 p-4">
              <div className="w-full flex justify-between items-center gap-4">
                <div className="flex flex-col w-[80%]">
                  <Label label={"Credit Card Number"} />
                  <div className="relative">
                    <Input
                      className="pr-12 bg-white"
                      type="text"
                      name="creditCardNumber"
                    />
                    <span className="absolute top-1 right-2">
                      <TiLockClosed className="w-8 h-8 fill-gray-500" />
                    </span>
                  </div>
                </div>
                <div className="flex flex-col w-[20%]">
                  <Label label={"Expiration"} />
                  <Input
                    className="bg-white"
                    type="text"
                    name="expiration"
                    placeholder={"MM/YY"}
                  />
                </div>
              </div>
              <div className="w-full flex justify-between items-center gap-4 mt-5">
                <div className="flex flex-col w-[80%]">
                  <Label label={"Name on Card"} />
                  <Input
                    className="bg-white"
                    type="text"
                    name="creditCardNumber"
                  />
                </div>
                <div className="flex flex-col w-[20%]">
                  <Label label={"CVV"} />
                  <div className="relative">
                    <Input className="bg-white" type="text" name="expiration" />
                    <span className="absolute top-1 right-2">
                      <TiLockClosed className="w-8 h-8 fill-gray-500" />
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="accordian-tab">
            <div className="accordian-header w-full flex justify-between items-center px-4">
              <RadioButton
                name="paymentCard"
                id="paypalCard"
                label={"Paypal"}
              />
              <div className="flex justify-end items-center ">
                <VisaIcon />
                <MasterCardIcon />
                <DiscoverIcon />
                <AmericanExpressIcon />
              </div>
            </div>
            <div className="accordian-body"></div>
          </div>
        </div>
        <Button className={"w-full py-3 px-4 uppercase text-xl mt-5"}>
          Place Order
        </Button>
      </div>
    </div>
  );
};

export default PaymentTab;
