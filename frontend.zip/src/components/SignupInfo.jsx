import React from "react";
import { Link } from "react-router";

const SignupInfo = () => {
  return (
    <div className="w-full mt-5 mb-8">
      <p className="text-sm font-normal font-primary text-primary">
        Already have an account?{" "}
        <Link
          className="customer-continue-button text-[#476bef] font-medium"
          id="checkout-customer-login"
          role="button"
          tabIndex="0"
        >
          Sign in now
        </Link>
      </p>
    </div>
  );
};

export default SignupInfo;
