import { API_URL } from "../../lib/constant";
import { setCustomerError } from "../../redux/errorSlice";

const bigcommerceLogoutAuth = async (dispatch) => {
  try {
    const response = await fetch(`${API_URL}/logout`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      credentials: "include",
    });

    const data = await response.json();

    if (!response.ok) {
      const message = data?.errors?.[0]?.message || "Logout failed";
      dispatch(setCustomerError(message));
      throw new Error(message);
    }

    return data;
  } catch (error) {
    const message = error?.message || "Logout failed";
    dispatch(setCustomerError(message));
    throw new Error(message);
  }
};

export default bigcommerceLogoutAuth;
