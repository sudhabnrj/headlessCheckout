import React from "react";

const LoginForm = () => {
  return (
    <form onSubmit={handleLogin}>
      <h3>Login</h3>
      <input
        type="email"
        value={email}
        placeholder="Email"
        onChange={(e) => setEmail(e.target.value)}
        required
      />
      <button type="submit">Login</button>
    </form>
  );
};

export default LoginForm;
