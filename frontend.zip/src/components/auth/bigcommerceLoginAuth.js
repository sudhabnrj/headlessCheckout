import { API_URL } from "../../lib/constant";
import { setCustomerError } from "../../redux/errorSlice";

export const loginBigCommerceUser = async (
  email,
  password,
  guestCartEntityId,
  dispatch
) => {
  try {
    const response = await fetch(`${API_URL}/login`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ email, password, guestCartEntityId }),
      credentials: "include",
    });

    if (!response.ok) {
      const errorMessage = data?.errors?.[0]?.message || "Login failed";
      throw new Error(errorMessage);
    }

    const data = await response.json();
    return data;
  } catch (error) {
    const message = error?.message || "Login failed";
    dispatch(setCustomerError(message));
    throw new Error(message);
  }
};
