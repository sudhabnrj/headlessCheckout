import React from "react";
import Container from "./ui/Container";
import { Link } from "react-router-dom";
import LOGO from "../assets/RMSM-logo.png";

const Header = () => {
  return (
    <header className="bg-secondary py-8 border-b border-b-gray-200">
      <Container>
        <h1 className="hidden is-srOnly">Checkout</h1>
        <h2 className="checkoutHeader-heading">
          <Link to="/" className="checkoutHeader-link">
            <img
              alt="Rocky Mountain Soap Market"
              className="checkoutHeader-logo"
              id="logoImage"
              src={LOGO}
            />
          </Link>
        </h2>
      </Container>
    </header>
  );
};

export default Header;
