import React from "react";
import Label from "./ui/Label";
import Input from "./ui/Input";
import Button from "./ui/Button";

const EmailForm = ({ custEmail, handleEmailChange }) => {
  return (
    <div className="w-full ">
      <Label label={"Email"} />
      <div className="flex gap-4">
        <Input
          type="text"
          name="firstName"
          placeholder="Enter your email"
          value={custEmail || ""}
          onChange={handleEmailChange}
        />
      </div>
    </div>
  );
};

export default EmailForm;
