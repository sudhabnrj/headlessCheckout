/* eslint-disable react/prop-types */
import React from "react";
import RadioButton from "./ui/RadioButton";

const ShippingOptions = ({ id, label, checked, onChange, shippingCost }) => {
  return (
    <div>
      <div
        className={`checkout-shipping-options border border-gray-300 p-5 w-full 
      bg-[#f5f5f5] ${checked ? "border-primary bg-blue-100" : ""}`}
      >
        <RadioButton
          name="customMethod"
          id={id}
          label={label}
          checked={checked}
          onChange={onChange}
          shippingCost={shippingCost}
        />
      </div>
    </div>
  );
};

export default ShippingOptions;
