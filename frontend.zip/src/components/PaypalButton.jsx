import { PayPalScriptProvider, PayPalButtons } from "@paypal/react-paypal-js";

export default function PaypalButton({ onSuccess, cartPrice }) {
  const initialOptions = {
    clientId: import.meta.env.VITE_PAYPAL_CLIENT_ID,
    currency: "USD",
  };

  const styles = {
    shape: "rect",
    layout: "vertical",
  };

  // const handlePlaceOrderWithPaypal = async (order) => {
  //   setLoading(true);
  //   try {
  //     const response = await placeOrder(
  //       checkoutID,
  //       "braintree.paypal",
  //       setIsPaymentError,
  //       setLoading,
  //       {
  //         payment: {
  //           instrument: {
  //             type: "paypal",
  //             paypal_order_id: order.id, // ✅ Use the PayPal Order ID
  //           },
  //           payment_method_id: "braintree.paypal",
  //         },
  //       }
  //     );

  //     if (response?.data?.status === "success") {
  //       dispatch(resetCheckout());
  //       dispatch(clearCart());
  //       dispatch(clearEmail());
  //       setSuccessMessage("Payment successful! Redirecting...");
  //     }
  //   } catch (error) {
  //     const errorMessage =
  //       error?.details?.title ||
  //       error?.message ||
  //       "PayPal order processing failed.";
  //     dispatch(setPaymentError(errorMessage));
  //   } finally {
  //     setLoading(false);
  //   }
  // };

  return (
    <div className="App">
      <PayPalScriptProvider options={initialOptions}>
        <PayPalButtons
          style={styles}
          fundingSource="paypal"
          createOrder={async (data, actions) => {
            if (!cartPrice || isNaN(cartPrice)) {
              console.error("Invalid cart price:", cartPrice);
              return;
            }
            return actions.order.create({
              intent: "CAPTURE",
              purchase_units: [
                {
                  amount: {
                    currency_code: "USD",
                    value: Number(cartPrice).toFixed(2), // ✅ Ensure it's a valid number
                  },
                },
              ],
            });
          }}
          onApprove={async (data, actions) => {
            try {
              const order = await actions.order.capture(); // ✅ Capture the payment
              console.log("Payment Captured:", order);

              // ✅ Send payment data to your backend
              onSuccess(order);
            } catch (error) {
              console.error("Payment Capture Error:", error);
            }
          }}
          onError={(err) => {
            console.error("PayPal Checkout Error:", err);
          }}
        />
      </PayPalScriptProvider>
    </div>
  );
}
